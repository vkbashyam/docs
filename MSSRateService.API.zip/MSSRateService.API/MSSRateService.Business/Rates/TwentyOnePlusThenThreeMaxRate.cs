﻿using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Extensions;
using Serilog;
using System.Linq;

namespace MSSRateService.Business
{
    public class TwentyOnePlusThenThreeMaxRate : RateFactory
    {
        private new readonly ILogger _log;

        public TwentyOnePlusThenThreeMaxRate(ILogger log) : base(log)
        {
            _log = log;
        }

        public override void SetBillable(FamilyUnitRequest family)
        {
            var sortedFamily = family.Person
                .OrderBy(m => m.BirthDate)
                .ThenBy(m => m.TobaccoUse.HasValue && m.TobaccoUse.Value)
                .ThenBy(m => m.LastName)
                .ThenBy(m => m.FirstName)
                .ThenBy(m => m.MiddleName).ToList();

            var dependentCount = 0;
            foreach (var member in sortedFamily)
            {
                if (member.IsMedicalSub.HasValue && member.IsMedicalSub.Value)
                {
                    switch (member.Relationship.ToUpper())
                    {
                        case "SELF":
                        case "SPOUSE":
                        case "EX - SPOUSE":
                        case "DOMESTIC PARTNER":
                            member.IsBillable = true;
                            break;
                        default:
                            if (member.Age.HasValue && member.Age.Value >= 21)
                                member.IsBillable = true;
                            else
                            {
                                ++dependentCount;

                                if (dependentCount <= 3)
                                    member.IsBillable = true;
                                else
                                    member.IsBillable = false;
                            }
                            break;
                    }
                }
                else
                {
                    member.IsBillable = true;
                }
            }

            _log
                .ForContext("Members", sortedFamily.Serialize())
                .Debug("Set billable members for contract {ContractNumber}", family.ContractNumber);
        }
    }
}
