﻿using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Extensions;
using Serilog;

namespace MSSRateService.Business
{
    public class EveryMemberRate : RateFactory
    {
        private new readonly ILogger _log;

        public EveryMemberRate(ILogger log) : base(log)
        {
            _log = log;
        }

        public override void SetBillable(FamilyUnitRequest family)
        {
            //every member is billable
            foreach (var member in family.Person)
                member.IsBillable = true;

            _log
                .ForContext("Members", family.Person.Serialize())
                .Debug("Set billable members for contract {ContractNumber}", family.ContractNumber);
        }
    }
}
