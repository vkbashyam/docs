﻿using MSSRateService.Common;
using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Interfaces;
using MSSRateService.Common.Interfaces.Rate;
using Serilog;
using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace MSSRateService.Business.RateRequests
{
    public class RateRequestByCensus : RateRequestFactory
    {
        private readonly ILogger _log;
        private readonly IModsService _mods;
        private readonly IRateBrainService _rateBrain;

        public RateRequestByCensus(ILogger log, IModsService mods, IRateBrainService rateBrain) : base(log, mods, rateBrain)
        {
            _log = log;
            _mods = mods;
            _rateBrain = rateBrain;
        }

        public RateRequest CreateRateRequest(CensusRequest census, string state, string county, string zip, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            var request = new RateRequest();
            request.RenewalDate = renewalDate;
            request.CoverageType = coverageType;
            request.PackageCode = packageCode;

            var groupData = new GroupMetadata();
            groupData.State = state;
            groupData.County = county;
            groupData.Zip = zip;
            groupData.LastRenewalDate = renewalDate;

            request.Group = groupData;
            request.Census = census;

            return request;
        }

        public override RateRequest CreateRateRequest(int id, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            throw new NotImplementedException("Method not available by census");
        }

        protected override List<XElement> GetGroupData(int id, DateTime renewalDate)
        {
            throw new NotImplementedException("Method not available by census");
        }

        protected override List<XElement> GetCensusData(int id, DateTime renewalDate)
        {
            throw new NotImplementedException("Method not available by census");
        }        
    }
}
