﻿using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Interfaces;
using MSSRateService.Common.Interfaces.Rate;
using Serilog;
using System;
using System.Collections.Generic;
using System.Xml.Linq;
using MSSRateService.Common;

namespace MSSRateService.Business.RateRequests
{
    public class RateRequestByGroup : RateRequestFactory
    {
        private readonly ILogger _log;
        private readonly IModsService _mods;
        private readonly IRateBrainService _rateBrain;

        public RateRequestByGroup(ILogger log, IModsService mods, IRateBrainService rateBrain) : base(log, mods, rateBrain)
        {
            _log = log;
            _mods = mods;
            _rateBrain = rateBrain;
        }

        public override RateRequest CreateRateRequest(int groupNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            var request = new RateRequest();

            request.RenewalDate = renewalDate;
            request.GroupNumber = groupNumber;
            request.CoverageType = coverageType;
            request.PackageCode = packageCode;

            var groupData = GetGroupData(groupNumber, renewalDate);
            var censusData = GetCensusData(groupNumber, renewalDate);

            var xml = CreateRawXml(groupData, censusData);
            request.Group = SerializeGroup(xml);
            request.Census = SerializeCensus(xml);            

            foreach (var validation in request.Census.Validations)
                request.ValidationMessages.Add(validation);

            return request;
        }

        protected override List<XElement> GetGroupData(int groupNumber, DateTime renewalDate)
        {
            return _mods.GetGroupData(groupNumber, renewalDate);
        }

        protected override List<XElement> GetCensusData(int groupNumber, DateTime renewalDate)
        {
            return _mods.GetCensusByGroup(groupNumber, renewalDate);
        }
    }
}
