﻿using MSSRateService.Common;
using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Extensions;
using MSSRateService.Common.Interfaces;
using MSSRateService.Common.Interfaces.Rate;
using Serilog;
using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace MSSRateService.Business.RateRequests
{
    public class RateRequestByContract : RateRequestFactory
    {
        private readonly ILogger _log;
        private readonly IModsService _mods;
        private readonly IRateBrainService _rateBrain;

        public RateRequestByContract(ILogger log, IModsService mods, IRateBrainService rateBrain) : base(log, mods, rateBrain)
        {
            _log = log;
            _mods = mods;
            _rateBrain = rateBrain;
        }

        public override RateRequest CreateRateRequest(int contractNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            var request = new RateRequest();            

            try
            {
                var contractData = GetGroupData(contractNumber, renewalDate);
                var censusData = GetCensusData(contractNumber, renewalDate);

                if (contractData.Count == 0)
                    throw new Exception("No contract data found");

                if (censusData.Count == 0)
                    throw new Exception("No census data found");

                var xml = CreateRawXml(contractData, censusData);
                request.Group = SerializeGroup(xml);
                request.Census = SerializeCensus(xml);

                if (request.Group == null || request.Census == null)
                    throw new Exception("Unable to serialize data");

                int groupNumber;
                int.TryParse(request.Group.GroupNumber, out groupNumber);
                if (groupNumber == 0)
                    throw new Exception("No group number found for contract");
                else
                    request.GroupNumber = groupNumber;
            }
            catch (Exception ex)
            {
                _log.Exception(ex);
                throw;
            }

            request.RenewalDate = renewalDate;            
            request.CoverageType = coverageType;
            request.PackageCode = packageCode;

            foreach (var validation in request.Census.Validations)
                request.ValidationMessages.Add(validation);

            return request;
        }

        protected override List<XElement> GetGroupData(int contractNumber, DateTime renewalDate)
        {
            return _mods.GetContractData(contractNumber, renewalDate);
        }

        protected override List<XElement> GetCensusData(int contractNumber, DateTime renewalDate)
        {
            return _mods.GetCensusByContract(contractNumber, renewalDate);
        }
    }
}
