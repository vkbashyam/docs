﻿using Aspose.Pdf;
using MSSRateService.Common;
using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Extensions;
using MSSRateService.Common.Interfaces;
using MSSRateService.Common.Interfaces.Rate;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Xml.Linq;
namespace MSSRateService.Business
{
    public abstract class RateRequestFactory : IRateRequest
    {
        readonly ILogger _log;
        readonly IModsService _mods;
        readonly IRateBrainService _rateBrain;

        const string ROOT_ELEMENT = "RAW_DATA";
        const string GROUP_ELEMENT = "MODS_GROUP_DATA";
        const string CENSUS_ELEMENT = "MODS_CENSUS_DATA";
        const string VALIDATION_ELEMENT = "VALIDATION_MESSAGES";

        public RateRequestFactory(ILogger log, IModsService mods, IRateBrainService rateBrain)
        {
            _log = log;
            _mods = mods;
            _rateBrain = rateBrain;
        }

        public abstract RateRequest CreateRateRequest(int id, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode);

        protected abstract List<XElement> GetGroupData(int id, DateTime renewalDate);

        protected abstract List<XElement> GetCensusData(int id, DateTime renewalDate);

        protected XElement CreateRawXml(List<XElement> group, List<XElement> census)
        {
            var rawData = new XElement(ROOT_ELEMENT);
            rawData.Add(new XElement(GROUP_ELEMENT));
            rawData.Add(new XElement(CENSUS_ELEMENT));
            rawData.Add(new XElement(VALIDATION_ELEMENT));

            var validation = new XElement("VALIDATION_MESSAGES");

            if (group == null || group.Count() == 0)
                //rawData.Element("VALIDATION_MESSAGES").Add(ValidationHelper.AddValidation(Enums.LogLevel.Error, "Group data not found in MODS."));
                rawData.Element("VALIDATION_MESSAGES").Add(new ValidationMessage(Enums.LogLevel.Error, "Group data not found in MODS."));

            if (census == null || census.Count() == 0)
                //rawData.Element("VALIDATION_MESSAGES").Add(ValidationHelper.AddValidation(Enums.LogLevel.Error, "Census data not found in MODS"));
                rawData.Element("VALIDATION_MESSAGES").Add(new ValidationMessage(Enums.LogLevel.Error, "Census data not found in MODS"));

            group.ForEach(m => rawData.Element("MODS_GROUP_DATA").Add(m));
            census.ForEach(m => rawData.Element("MODS_CENSUS_DATA").Add(m));

            rawData.Element("MODS_GROUP_DATA").SetAttributeValue("count", group.Count());
            rawData.Element("MODS_CENSUS_DATA").SetAttributeValue("count", group.Count());
            rawData.Element("VALIDATION_MESSAGES").SetAttributeValue("count", validation.Elements().Count());

            if (Debugger.IsAttached)
                rawData.Save(@$"C:/users/{Environment.UserName}/desktop/raw.xml");

            _log.ForContext("RawData", rawData).Debug("Retrieved Raw Data");

            return rawData;
        }

        protected GroupMetadata SerializeGroup(XElement xml)
        {
            var groupXml = xml.Element(GROUP_ELEMENT);

            if (groupXml == null || groupXml.Elements().Count() == 0)
            {
                _log.Warning("No Group data found");
                return null;
            }

            var group = new GroupMetadata();
            var first = groupXml.Elements().First();

            group.GroupNumber = first.GetElementValueByName("GRP_NO");

            DateTime lastRenewalDate;
            if (DateTime.TryParse(first.GetElementValueByName("LAST_RENEWAL_DT"), out lastRenewalDate))
                group.LastRenewalDate = lastRenewalDate;

            group.State = first.GetElementValueByName("STATE_ABRV");
            group.County = first.GetElementValueByName("COUNTY_NM");
            group.Zip = first.GetElementValueByName("ZIPCODE_CD");
            group.DefaultCounty = first.GetElementValueByName("DEFAULT_COUNTY");
            group.MarketSegment = first.GetElementValueByName("MARKET_SEGMENT");
            group.MarketSegmentId = first.GetElementValueByName("MRKT_SEG_ID");
            group.Grandfathered = first.GetElementValueByName("GRANDFATHER_FLG");

            DateTime grandfatheredEffectiveDate;
            if (DateTime.TryParse(first.GetElementValueByName("GF_EFF_DT"), out grandfatheredEffectiveDate))
                group.GrandfatheredEffectiveDate = grandfatheredEffectiveDate;

            DateTime grandfatheredEndDate;
            if (DateTime.TryParse(first.GetElementValueByName("GF_END_DT"), out grandfatheredEndDate))
                group.GrandfatheredEndDate = grandfatheredEndDate;

            group.ContractAdjustmentFactor = 1;
            if (first.GetElementValueByName("MARKET_SEGMENT") == "INDIVIDUAL" && !string.IsNullOrEmpty(first.GetElementValueByName("CONTRACT_NO")))
            {
                var contractNumber = int.Parse(first.GetElementValueByName("CONTRACT_NO"));
                group.ContractAdjustmentFactor = _mods.GetContractAdjustmentFactorByContract(contractNumber);
            }

            group.LicensingCorpId = first.GetElementValueByName("LCNSE_CORP_ID");
            group.LicensingState = first.GetElementValueByName("LCNSING_STATE");
            group.LicensingCorpAbrv = first.GetElementValueByName("LCNSE_CORP_ABRV");
            group.LicensingCorpName = first.GetElementValueByName("LCNSE_CORP_NM");

            var subGroups = groupXml.Elements().Select(m => new
            {
                SubGroupName = m.GetElementValueByName("SUBGRP_NM"),
                SubGroupTypeId = m.GetElementValueByName("SUBGRP_TP_ID"),
                SiteId = m.GetElementValueByName("SITE_ID_NO")
            }).ToList().Distinct();

            foreach (var subGroup in subGroups)
            {
                if (string.IsNullOrWhiteSpace(subGroup.SubGroupName) && string.IsNullOrWhiteSpace(subGroup.SubGroupTypeId))
                    continue;

                var sg = new SubGroup();

                sg.Name = subGroup.SubGroupName;
                sg.TypeId = subGroup.SubGroupTypeId;
                sg.SiteId = subGroup.SiteId;
                sg.IsCobra = sg.TypeId == "2";
                sg.IsMedicare = sg.SiteId == "65+";

                var plans = groupXml.Elements().Where(m => m.GetElementValueByName("SUBGRP_NM") == sg.Name && m.GetElementValueByName("SUBGRP_TP_ID") == sg.TypeId && m.GetElementValueByName("SITE_ID_NO") == sg.SiteId).ToList();
                foreach (var plan in plans)
                {
                    var sgp = new SubGroupPlan();

                    sgp.NetworkId = plan.GetElementValueByName("DELIVERY_NETWORK_ID");
                    sgp.PackageCode = plan.GetElementValueByName("BEN_PKG_CD");
                    sgp.ContractAdjustmentFactor = plan.GetElementValueByName("CNTR_ADJ_FACTOR_NO");
                    sgp.PackageType = plan.GetElementValueByName("BEN_PKG_TP");
                    sgp.HospiceFlag = plan.GetElementValueByName("BEN_PKG_HOSPICE_FLG");
                    sgp.PedicatricDentalFlag = plan.GetElementValueByName("BEN_PKG_PED_DENTL_FLG");

                    sg.Plans.Add(sgp);
                }

                group.SubGroups.Add(sg);
            }

            if (Debugger.IsAttached)
                File.WriteAllText(@$"c:/users/{Environment.UserName}/desktop/group.xml", group.Serialize());

            _log.ForContext("Group", group.Serialize()).Debug("Retrieved Group Data");

            return group;
        }

        protected CensusRequest SerializeCensus(XElement xml)
        {
            var censusXml = xml.Element(CENSUS_ELEMENT);

            if (censusXml == null || censusXml.Elements().Count() == 0)
            {
                _log.Warning("No Census data found");
                return null;
            }

            var census = new CensusRequest();
            var contracts = censusXml.Elements().GroupBy(m => m.GetElementValueByName("CONTRACT_NO")).ToList();

            foreach (var contract in contracts)
            {
                var family = new FamilyUnitRequest();
                var common = contract.First();

                family.ContractNumber = common.GetElementValueByName("CONTRACT_NO");

                if (!string.IsNullOrEmpty(common.GetElementValueByName("SUBGRP_TP_ID")))
                {
                    family.IsCobraSpecified = true;
                    family.IsCobra = common.GetElementValueByName("SUBGRP_TP_ID") == "2";
                }
                else
                {
                    family.IsCobraSpecified = false;
                    family.IsCobra = false;
                }

                if (!string.IsNullOrEmpty(common.GetElementValueByName("SITE_ID_NO")))
                {
                    family.IsMedicareSpecified = true;
                    family.IsMedicare = common.GetElementValueByName("SITE_ID_NO") == "65+";
                }

                foreach (var member in contract)
                {
                    var person = new PersonRequest();

                    person.FirstName = member.GetElementValueByName("FIRST_NM");
                    person.MiddleName = member.GetElementValueByName("MIDDLE_NM");
                    person.LastName = member.GetElementValueByName("LAST_NM");

                    DateTime DOB;
                    if (DateTime.TryParse(member.GetElementValueByName("BIRTH_DT"), out DOB))
                        person.BirthDate = DOB;
                    else
                        census.Validations.Add(new ValidationMessage(Enums.LogLevel.Error, $"Cannot have empty birthdate field. See {person.Name}"));

                    person.Gender = member.GetElementValueByName("GENDER_CD");
                    person.Relationship = member.GetElementValueByName("REL_TXT");
                    person.TobaccoUse = member.GetElementValueByName("TOBACCOUSE") == "Y";
                    person.TobaccoCessation = false;

                    int medicalCount = 0;
                    int.TryParse(member.GetElementValueByName("MEDCOUNT"), out medicalCount);
                    person.IsMedicalSub = medicalCount > 0;

                    int dentalCount = 0;
                    int.TryParse(member.GetElementValueByName("DENTCOUNT"), out dentalCount);
                    person.IsDentalSub = dentalCount > 0;

                     
                    person.AdditionalDemographics.Demographics.Add(new XElement("MemberId", member.GetElementValueByName("EXTERNAL_PERSON_ID")));
                    person.AdditionalDemographics.Demographics.Add(new XElement("State", member.GetElementValueByName("STATE_CD")));
                    person.AdditionalDemographics.Demographics.Add(new XElement("DSNID", member.GetElementValueByName("DSN_ID")));
                    person.AdditionalDemographics.Demographics.Add(new XElement("TobaccoCode", member.GetElementValueByName("TOBACCOUSE")));
                    person.AdditionalDemographics.Demographics.Add(new XElement("REL_TO_PH", member.GetElementValueByName("REL_TO_PH")));

                    DateTime tobaccoDate;
                    if (DateTime.TryParse(member.GetElementValueByName("TOBACCODATE"), out tobaccoDate))
                        person.TobaccoUpdatedDate = tobaccoDate;

                    family.Person.Add(person);
                }

                census.FamilyUnit.Add(family);
            }

            if (Debugger.IsAttached)
                File.WriteAllText(@$"c:/users/{Environment.UserName}/desktop/census.xml", census.Serialize());

            _log.ForContext("Census", census.Serialize()).Debug("Retrieved Census Data");

            return census;
        }

        public bool CalculateRateRequest(RateRequest request)
        {
            if (!IsValid(request))
                throw new Exception("Invalid rate request");

            request.PlanFactor = GetPlanFactors(request);
            if (request.PlanFactor == null)
            {
                _log.Warning("Unable to get plan factors");
                return false;
            }

            request.AgeBands = GetAgeBands(request.CoverageType, request.PlanFactor.AgeBandSet);
            if (request.AgeBands == null)
            {
                _log.Warning("Unable to get age bands");
                return false;
            }

            var rateClass = GetRateClass(request.PlanFactor.DependentCountMethod);
            if (rateClass.UpdateFamilyRate(request))
            {
                if (Debugger.IsAttached)
                    File.WriteAllText(@$"c:/users/{Environment.UserName}/desktop/rate.xml", request.Serialize());

                _log
                .ForContext("RateRequest", request.Serialize())
                .Information("Calculated rate request");

                return true;
            }

            return false;
        }

        protected bool IsValid(RateRequest request)
        {
            var isValid = true;

            if (request == null)
            {
                _log.Warning("No request information received");
                throw new Exception("No request information received");
            }

            //check validation messages
            if (request.ValidationMessages.Count > 0)
            {
                _log
                    .ForContext("ValidationMessages", request.ValidationMessages)
                    .Warning("Validation errors on the request");

                isValid = false;
            }

            #region Group Validation - required for plan factors
            if (request.Group == null)
            {
                _log.Warning("No group data found on request");
                isValid = false;
            }
            else
            {
                if (string.IsNullOrWhiteSpace(request.Group.State))
                {
                    _log.Warning("Group data missing state field");
                    isValid = false;
                }

                if (string.IsNullOrWhiteSpace(request.Group.County))
                {
                    _log.Warning("Group data missing county field");
                    isValid = false;
                }

                if (string.IsNullOrWhiteSpace(request.Group.Zip))
                {
                    _log.Warning("Group data missing zip field");
                    isValid = false;
                }
            }
            #endregion

            #region Census Validation - required for calculating rate
            if (request.Census == null)
            {
                _log.Warning("No census data found on request");
                isValid = false;
            }
            else
            {
                if (request.Census.FamilyUnit == null || request.Census.FamilyUnit.Count == 0)
                {
                    _log.Warning("No families found on census");
                    isValid = false;
                }
                else
                {
                    if (request.Census.FamilyUnit.SelectMany(m => m.Person).Any(m => m.Age == null))
                    {
                        _log.Warning("Census members missing age field");
                        isValid = false;
                    }

                    if (request.Census.FamilyUnit.SelectMany(m => m.Person).Any(m => m.Relationship == null))
                    {
                        _log.Warning("Census members missing relationship field");
                        isValid = false;
                    }
                }
            }
            #endregion

            return isValid;
        }

        private PlanFactor GetPlanFactors(RateRequest request)
        {
            var group = request.Group;
            var census = request.Census;
            var renewalDate = request.RenewalDate;
            var coverageType = request.CoverageType;
            var packageCode = request.PackageCode;

            if (string.IsNullOrEmpty(group.County) && string.IsNullOrEmpty(group.DefaultCounty))
            {
                _log.Warning("No county data available to get rate information");
                throw new Exception("No county data available to get rate information");
            }

            var county = !string.IsNullOrEmpty(group.County) ? group.County : group.DefaultCounty;
            var state = group.State;

            var medicalMemberCount = 0;
            if (coverageType == Enums.CoverageType.Medical)
                medicalMemberCount = census.FamilyUnit.SelectMany(m => m.Person).Where(m => m.IsMedicalSub == true).Count();

            var planFactors = _rateBrain.GetPlanFactors(coverageType, packageCode, renewalDate, county, state, medicalMemberCount);

            if (planFactors == null || planFactors.Count() == 0)
            {
                _log.Warning("No plan factors found in RateBrain");
                throw new Exception("No plan factors found in RateBrain");
            }
            else if (planFactors.Count() > 1)
            {
                _log.Warning("Multiple plan factors found in RateBrain (Expecting one record)");
                throw new Exception("Multiple plan factors found in RateBrain (Expecting one record)");
            }
            else
            {
                var planElement = planFactors.First();

                if (planElement.NetworkFactor == null && (planElement.MaxNetworkFactor == null || planElement.AreaFactor == null))
                {
                    _log.Warning("Required plan factors are missing");
                    throw new Exception("Required plan factors are missing");
                }

                return planElement;
            }
        }

        private List<AgeBand> GetAgeBands(Enums.CoverageType coverageType, int ageBandSet)
        {
            var ageBands = _rateBrain.GetAgeBands(coverageType, ageBandSet);

            return ageBands;
        }

        private IRate GetRateClass(string depCountMethod)
        {
            IRate rate;

            switch (depCountMethod)
            {
                case "3":
                    rate = new EveryMemberRate(_log);
                    break;
                case "2":
                    rate = new ThreeDependentRate(_log);
                    break;
                case "1":
                    rate = new TwentyOnePlusThenThreeMaxRate(_log);
                    break;
                default:
                    _log.Warning("Rate class for {DepCountMethod} was not found", depCountMethod);
                    throw new Exception($"Rate class not defined for {depCountMethod}");
            }

            return rate;
        }
    }
}
