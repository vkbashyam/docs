﻿using MSSRateService.Common.Interfaces.Rate;
using MSSRateService.Common.DataTransferObjects.Rate;
using Serilog;
using System;
using System.Linq;
using MSSRateService.Common.Extensions;

namespace MSSRateService.Business
{
    public abstract class RateFactory : IRate
    {
        protected readonly ILogger _log;

        public RateFactory(ILogger log)
        {
            _log = log;
        }

        public bool UpdateAgeBands(RateRequest request)
        {
            if (!request.PlanFactor.RiskPoolBaseRate.HasValue)
            {
                _log.Warning("Plan Factor risk pool base rate is not set");
                return false;
            }

            if (!request.PlanFactor.AreaFactor.HasValue)
            {
                _log.Warning("Plan Factor area factor is not set");
                return false;
            }

            if (!request.PlanFactor.NetworkFactor.HasValue && !request.PlanFactor.MaxNetworkFactor.HasValue)
            {
                _log.Warning("Plan Factor network or max network factor is not set");
                return false;
            }

            decimal riskPoolBaseRate = request.PlanFactor.RiskPoolBaseRate.Value;
            decimal planFactor = request.PlanFactor.Factor;
            decimal areaFactor = request.PlanFactor.AreaFactor.Value;
            decimal networkFactor = request.PlanFactor.NetworkFactor != null ? request.PlanFactor.NetworkFactor.Value : request.PlanFactor.MaxNetworkFactor.Value;
            decimal groupAdjustmentFactor = 1;
            decimal contractAdjustmentFactor = request.PlanFactor.Grandfathered == 1 ? request.Group.ContractAdjustmentFactor : 1;

            foreach (var ageband in request.AgeBands)
            {
                decimal ageFactor = ageband.AgeFactor;
                decimal tobaccoFactor = ageband.TobaccoFactor;

                /*
                    ROUND(
                        ROUND(  [RiskPoolBaseRate] * 
                                [PlanFactor] * 
                                [AreaFactor] * 
                                [NetworkFactor] * 
                                [TobaccoFactor] * //excluded depending if tobacco/non-tobacco
                                [HealthAndWellnessFactor] * //excluded
                                [MemberAdjustmentFactor] * //excluded
                                [GroupAdjustmentFactor] *
                                [ContractAdjustmentFactor], 2) * [AgeFactor]), 2)            
                */

                decimal partialNonTobaccoRate = Math.Round(riskPoolBaseRate * planFactor * areaFactor * networkFactor * groupAdjustmentFactor * contractAdjustmentFactor, 2, MidpointRounding.AwayFromZero);
                decimal partialTobaccoRate = Math.Round(riskPoolBaseRate * planFactor * areaFactor * networkFactor * tobaccoFactor * groupAdjustmentFactor * contractAdjustmentFactor, 2, MidpointRounding.AwayFromZero);

                ageband.NonTobaccoRate = Math.Round(partialNonTobaccoRate * ageFactor, 2, MidpointRounding.AwayFromZero);
                ageband.TobaccoRate = Math.Round(partialTobaccoRate * ageFactor, 2, MidpointRounding.AwayFromZero);
            }

            _log
                .ForContext("AgeBands", request.AgeBands.Serialize())
                .Debug("Updated age bands");

            return true;
        }

        public bool UpdateFamilyRate(RateRequest request)
        {
            if (!UpdateAgeBands(request))
            {
                _log.Warning("Failed to update age bands");
                return false;
            }

            foreach (var family in request.Census.FamilyUnit)
            {
                foreach (var member in family.Person)
                    member.AgeByRenewalDate = member.CalculateAge(request.RenewalDate);

                SetBillable(family);

                foreach (var member in family.Person)
                {
                    if (member.IsBillable.HasValue && member.IsBillable.Value)
                    {
                        var isMemberMale = (string.IsNullOrEmpty(member.Gender) || member.Gender.ToUpper().StartsWith("M")) ? true : false;
                        var memberAgeBand = request.AgeBands.Where(m => m.MinimumAge <= member.AgeByRenewalDate && m.MaximumAge >= member.AgeByRenewalDate && (m.MaleBand == isMemberMale || m.FemaleBand == !isMemberMale)).ToList();

                        //if (string.IsNullOrWhiteSpace(member.AgeBandType))

                        if (memberAgeBand.Count > 1)
                        {
                            _log
                                .ForContext("Member", member)
                                .ForContext("AgeBands", memberAgeBand)
                                .Warning("Multiple possible age bands found for member");

                            throw new Exception("Multiple possible age bands found for member");
                        }
                        else if (memberAgeBand.Count == 0)
                        {
                            _log
                                .ForContext("Member", member)
                                .Warning("No age band found for member");

                            throw new Exception("No age band found for member");
                        }
                        else
                        {
                            member.Rate = (member.TobaccoUse.HasValue && member.TobaccoUse.Value) ? memberAgeBand.First().TobaccoRate : memberAgeBand.First().NonTobaccoRate;
                        }
                    }
                    //by default the member rate is 0.0;                                        

                    family.Rate += member.Rate;
                    if (member.IsMedicalSub.HasValue && member.IsMedicalSub.Value)
                        family.MedicalSubscriberRate += member.Rate;
                }

                request.Census.Rate += family.Rate;
                request.Census.MedicalSubscriberRate += family.MedicalSubscriberRate;
            }

            return true;
        }

        public abstract void SetBillable(FamilyUnitRequest family);
    }
}
