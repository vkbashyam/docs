﻿using MSSRateService.Common.Interfaces.Rate;
using MSSRateService.Common.Interfaces;
using Serilog;
using System;
using MSSRateService.Common;
using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Business.RateRequests;

namespace MSSRateService.Business.Services
{
    public class RateService : IRateService
    {
        private readonly ILogger _log;
        private readonly IModsService _mods;
        private readonly IRateBrainService _rateBrain;

        public RateService(ILogger log, IModsService mods, IRateBrainService rateBrain)
        {
            _log = log;
            _mods = mods;
            _rateBrain = rateBrain;
        }
        
        public RateRequest RateRequestByGroup(int groupNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            var requestFactory = new RateRequestByGroup(_log, _mods, _rateBrain);
            var request = requestFactory.CreateRateRequest(groupNumber, renewalDate, coverageType, packageCode);

            if (requestFactory.CalculateRateRequest(request))
            {
                return request;
            }

            //fallback
            throw new Exception("Unable to process rate request by group");
        }

        public RateRequest RateRequestByContract(int contractNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            var requestFactory = new RateRequestByContract(_log, _mods, _rateBrain);
            var request = requestFactory.CreateRateRequest(contractNumber, renewalDate, coverageType, packageCode);

            if (requestFactory.CalculateRateRequest(request))
            {
                return request;
            }

            //fallback
            throw new Exception("Unable to process rate request by contract");
        }

        public RateRequest RateRequestByCensus(CensusRequest census, string state, string county, string zip, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            var requestFactory = new RateRequestByCensus(_log, _mods, _rateBrain);
            var request = requestFactory.CreateRateRequest(census, state, county, zip, renewalDate, coverageType, packageCode);              

            if (requestFactory.CalculateRateRequest(request))
            {
                return request;
            }

            //fallback
            throw new Exception("Unable to process rate request by census");
        }
    }
}
