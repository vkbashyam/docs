﻿using Microsoft.EntityFrameworkCore;
using MSSRateService.Common.DataTransferObjects;
using MSSRateService.Common.Extensions;
using MSSRateService.Common.Interfaces;
using MSSRateService.Domain.Models.ProcessLog;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using MSSRateService.Common;
using Newtonsoft.Json.Linq;

namespace MSSRateService.Business.Services
{
    public class ProcessLogService : IProcessLogService
    {
        private readonly ProcessLogContext _db;
        private readonly ILogger _log;

        public ProcessLogService(ProcessLogContext db, ILogger log)
        {
            _db = db;
            _log = log;
        }

        public Dictionary<int, string> GetProcesses()
        {
            var dict = new Dictionary<int, string>();

            using (var tran = _db.Database.BeginTransaction())
            {
                dict = _db.Processes.ToDictionary(m => m.ProcessId, n => n.Name);
            }

            return dict;
        }

        public int Log(int processId, int statusId, string assembly, string version, string jsonData, HttpResponseDto response)
        {
            using (var tran = _db.Database.BeginTransaction())
            {
                try
                {
                    var log = new Domain.Models.ProcessLog.Log();

                    log.ProcessId = processId;
                    log.TimeStamp = DateTime.Now;
                    log.Assembly = assembly;
                    log.Version = version;
                    log.StatusId = statusId;
                    log.JsonData = jsonData;

                    _db.Logs.Add(log);
                    _db.SaveChanges();

                    tran.Commit();
                    return log.LogId;
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    _log.Exception(ex, "Failed to save log record.");

                    if (response != null)
                        response.Message = ex.ToString();

                    return 0;
                }
            }
        }

        public int Log(int processId, int statusId, string assembly, string version, JObject json)
        {
            using (var tran = _db.Database.BeginTransaction())
            {
                try
                {
                    var log = new Domain.Models.ProcessLog.Log();

                    log.ProcessId = processId;
                    log.TimeStamp = DateTime.Now;
                    log.Assembly = assembly;
                    log.Version = version;
                    log.StatusId = statusId;
                    log.JsonData = JsonConvert.SerializeObject(json);

                    _db.Logs.Add(log);
                    _db.SaveChanges();

                    tran.Commit();
                    return log.LogId;
                }
                catch (Exception ex)
                {
                    tran.Rollback();
                    _log.Exception(ex, "Failed to save log record.");

                    return 0;
                }
            }
        }

        IEnumerable<LogDto> IProcessLogService.GetLogs(int processId, int transactionId, DateTime start, DateTime? end)
        {
            throw new NotImplementedException();
        }
    }
}
