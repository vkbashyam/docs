﻿using MSSRateService.Common.Extensions;
using MSSRateService.Common.Interfaces;
using Newtonsoft.Json;
using Oracle.ManagedDataAccess.Client;
using Serilog;
using System.Data;
using System.Numerics;
using System.Xml.Linq;

namespace MSSRateService.Business.Services
{
    public class ModsService : IModsService
    {
        private readonly string _ModsConnectionString;
        private readonly ILogger _seriLogger;

        private const string METADATA_ELEMENT = "METADATA";
        private const string MEMBER_ELEMENT = "MEMBER";
        private const string MEMBER_PLANS = "PLANS";

        public ModsService(ILogger seriLogger)
        {
            //always target production dataset
            _ModsConnectionString = "DATA SOURCE=eimdbprd:1551/adwprd.healthpartners.com;PERSIST SECURITY INFO=True;USER ID=HPSALESMRKT2;Password=b0bb0bB0bbing;";
            _seriLogger = seriLogger;
        }

        public List<XElement> GetGroupData(int groupNumber, DateTime renewalDate)
        {
            var results = new List<XElement>();

            try
            {
                _seriLogger.Information("Getting group data for {GroupNumber} with renewal date {RenewalDate}", groupNumber, renewalDate.ToShortDateString());
                using (OracleConnection conn = new OracleConnection(_ModsConnectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"select
                                                g.grp_no
                                                ,g.last_renewal_dt
                                                ,g.state_abrv
                                                ,g.county_nm
                                                ,g.zipcode_cd
                                                ,subgrp.subgrp_nm
                                                ,subgrp.subgrp_tp_id
                                                ,gsp.mrkt_seg_id
                                                ,gsp.lcnse_corp_id
                                                ,gsp.delivery_network_id
                                                ,msd.mrkt_seg_desc as MARKET_SEGMENT
                                                ,bp.ben_pkg_cd
                                                ,bp.ben_pkg_tp
                                                ,bp.ben_pkg_tp_cd
                                                ,bp.ben_pkg_hospice_flg
                                                ,bp.ben_pkg_ped_dentl_flg
                                                ,pd.lcnsing_state
                                                ,lcd.lcnse_corp_nm
                                                ,lcd.lcnse_corp_abrv
                                                ,gsite.site_id_no
                                            FROM mods.grp_ds g
                                            inner join mods.gs1 subgrp on g.grp_id = subgrp.grp_id
                                            inner join mods.grp_subgrp_pkg_ds gsp on gsp.grp_id = subgrp.grp_id
                                                and gsp.subgrp_id = subgrp.subgrp_id
                                            inner join adw.mrkt_seg_ds msd on gsp.mrkt_seg_id = msd.mrkt_seg_id
                                            inner join mods.ben_pkg_ds bp on bp.ben_pkg_id = gsp.ben_pkg_id
                                            inner join mods.prod_ds pd on pd.prod_id = gsp.prod_id
                                            inner join adw.lcnse_corp_ds lcd on pd.lcnse_corp_id = lcd.lcnse_corp_id
                                            inner join subgrp_ds gsite on subgrp.subgrp_id = gsite.subgrp_id
                                            where g.grp_no = :groupNumber
                                                and :renewalDate between gsp.eff_dt and gsp.end_dt
                                                and :renewalDate between subgrp.eff_dt and subgrp.end_dt";
                        cmd.BindByName = true;
                        // Replace all instances of cmd.AddParameter(...) with the following pattern:
                        cmd.Parameters.Add(new OracleParameter(":renewalDate", OracleDbType.Varchar2) { Value = renewalDate.Date.ToString("dd-MMM-yyyy") });
                        cmd.Parameters.Add(new OracleParameter(":groupNumber", OracleDbType.Varchar2) { Value = groupNumber.ToString("D4") });


                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                results.Add(reader.ToXml(METADATA_ELEMENT));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }

            _seriLogger.Debug("Retrieved {Count} records for group data", results.Count);
            return results;
        }

        public List<XElement> GetCensusByGroup(int groupNumber, DateTime renewalDate)
        {
            var results = new List<XElement>();

            try
            {
                _seriLogger.Information("Getting member census for group {GroupNumber} with renewal date {RenewalDate}", groupNumber, renewalDate.ToShortDateString());
                using (OracleConnection conn = new OracleConnection(_ModsConnectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"select
                                                mbd.contract_no
                                                ,person.last_nm
                                                ,person.middle_nm
                                                ,person.first_nm
                                                ,person.birth_dt
                                                ,person.external_person_id
                                                ,person.gender_cd
                                                ,person.state_cd
                                                ,mbe.dsn_id
                                                ,mbe.rel_to_ph
                                                ,subgrp.subgrp_nm
                                                ,subgrp.subgrp_tp_id
                                                ,subgrp.site_id_no
                                                ,pcri.LATEST_TOBACCO_USAGE_CD as TobaccoUse
                                                ,pcri.LATEST_FILED_DT as TobaccoDate
                                                ,rel_ds.rel_txt
                                                ,count(bpm.ben_pkg_cd) MedCount
                                                ,count(bpd.ben_pkg_cd) DentCount
                                            from mods.grp_ds grp
                                            inner join mods.mbd mbd on grp.grp_id = mbd.grp_id
                                            inner join mods.mbe mbe on mbd.contract_no = mbe.contract_no
                                            inner join mods.subgrp_ds subgrp on mbd.subgrp_id = subgrp.subgrp_id
                                            inner join mods.person_ds person on person.person_no = mbe.person_no
                                            left join mods.person_cntr_rate_item_ds pcri  on pcri.person_no = person.person_no
                                                and pcri.contract_no = mbe.contract_no
                                            left join adw.rel_ds on rel_ds.rel_cd = mbe.rel_to_ph
                                            left join mods.mbr_og2 og2 on mbe.person_no = og2.person_no
                                                and mbe.contract_no = og2.contract_no
                                                and :renewalDate BETWEEN og2.eff_dt and og2.end_dt       
                                            left join mods.ben_pkg_ds bpm on og2.ben_pkg_id = bpm.ben_pkg_id
                                                and bpm.ben_pkg_tp_cd = 'M'     
                                            left join mods.ben_pkg_ds bpd on og2.ben_pkg_id = bpd.ben_pkg_id
                                                and bpd.ben_pkg_tp_cd = 'D'
                                            where grp.grp_no = :groupNumber
                                                and :renewalDate between mbd.eff_dt and mbd.end_dt
                                                and :renewalDate between mbe.eff_dt and mbe.end_dt
                                            group by 
                                                mbd.contract_no
                                                ,subgrp.subgrp_nm
                                                ,subgrp.subgrp_tp_id
                                                ,subgrp.site_id_no
                                                ,person.person_no
                                                ,person.last_nm
                                                ,person.middle_nm
                                                ,person.first_nm
                                                ,person.birth_dt
                                                ,person.external_person_id
                                                ,person.gender_cd
                                                ,person.state_cd
                                                ,mbe.dsn_id
                                                ,mbe.rel_to_ph
                                                ,pcri.LATEST_TOBACCO_USAGE_CD
                                                ,pcri.LATEST_FILED_DT
                                                ,rel_ds.rel_txt";

                        cmd.BindByName = true;
                        // Replace all instances of cmd.AddParameter(...) with the following pattern:
                        cmd.Parameters.Add(new OracleParameter(":renewalDate", OracleDbType.Varchar2) { Value = renewalDate.Date.ToString("dd-MMM-yyyy") });
                        cmd.Parameters.Add(new OracleParameter(":groupNumber", OracleDbType.Varchar2) { Value = groupNumber.ToString("D4") });


                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                results.Add(reader.ToXml(MEMBER_ELEMENT));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }

            _seriLogger.Debug("Retrieved {Count} records for census data", results.Count);
            return results;
        }

        public List<XElement> GetMemberPlans(int groupNumber, DateTime renewalDate)
        {
            var results = new List<XElement>();

            try
            {
                _seriLogger.Information("Getting plans for group {GroupNumber} with renewal date {RenewalDate}", groupNumber, renewalDate.ToShortDateString());

                using (OracleConnection conn = new OracleConnection(_ModsConnectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"select distinct
                                                g.grp_no
                                                ,g.last_renewal_dt
                                                ,c.contract_no
                                                ,membermbe.person_no
                                                ,bp.ben_pkg_cd
                                                ,gsp.mrkt_seg_id
                                                ,msd.mrkt_seg_desc as market_segment
                                                ,gsp.lcnse_corp_id
                                                ,gsp.delivery_network_id 
                                                ,bp.ben_pkg_tp
                                                ,bp.ben_pkg_tp_cd
                                                ,bp.ben_pkg_hospice_flg
                                                ,bp.ben_pkg_ped_dentl_flg
                                            from mods.grp_ds g
                                            inner join mods.mbd c on g.grp_id = c.grp_id
                                            inner join mods.mbe membermbe on membermbe.contract_no = c.contract_no
                                            inner join mods.mbr_og2 og2 on og2.person_no = membermbe.person_no
                                                and og2.contract_no = membermbe.contract_no
                                            --gsp is a link to the prod id.
                                            inner join mods.grp_subgrp_pkg_ds gsp on gsp.grp_id = c.grp_id
                                                and gsp.subgrp_id = c.subgrp_id
                                                and gsp.ben_pkg_id = og2.ben_pkg_id
                                            inner join adw.mrkt_seg_ds msd on gsp.mrkt_seg_id = msd.mrkt_seg_id
                                            inner join mods.ben_pkg_ds bp on bp.ben_pkg_id = og2.ben_pkg_id
                                            where g.grp_no = :groupNumber
                                                and :renewalDate between c.subgrp_eff_dt and c.subgrp_end_dt
                                                and :renewalDate between membermbe.eff_dt and membermbe.end_dt
                                                and :renewalDate between og2.eff_dt and og2.end_dt
                                                and :renewalDate between gsp.eff_dt and gsp.end_dt
                                            order by c.contract_no, membermbe.person_no";

                        cmd.BindByName = true;
                        // Replace all instances of cmd.AddParameter(...) with the following pattern:
                        cmd.Parameters.Add(new OracleParameter(":renewalDate", OracleDbType.Varchar2) { Value = renewalDate.Date.ToString("dd-MMM-yyyy") });
                        cmd.Parameters.Add(new OracleParameter(":groupNumber", OracleDbType.Varchar2) { Value = groupNumber.ToString("D4") });


                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                results.Add(reader.ToXml(MEMBER_PLANS));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }

            _seriLogger.Debug("Retrieved {Count} plan(s)", results.Count);
            return results;
        }

        public decimal GetContractAdjustmentFactorByContract(int contractNumber)
        {
            decimal contractAdjustmentFactor = 1;

            try
            {
                _seriLogger.Information("Getting contract adjustment factor for contract {ContractNumber}", contractNumber);
                using (OracleConnection conn = new OracleConnection(_ModsConnectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"select caf.cntr_adj_factor_no
                                            from adw.indiv_rated_cont_hist_ds caf
                                            left join (--get latest earned month for the contract
                                                select 
                                                    contract_no
                                                    ,max(chg_dt) as maxchangedate
                                                from adw.indiv_rated_cont_hist_ds
                                                where stat_cd = 'P'
                                                    and cntr_adj_factor_no <> 1
                                                group by contract_no
                                            ) mxcaf on caf.contract_no = mxcaf.contract_no
                                                and caf.chg_dt = mxcaf.maxchangedate
                                            where  caf.stat_cd = 'P'
                                                and caf.cntr_adj_factor_no <> 1
                                                and caf.contract_no = :ContractNo";

                        cmd.BindByName = true;
                        cmd.Parameters.Add(new OracleParameter(":ContractNo", OracleDbType.Varchar2) { Value = contractNumber });



                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                contractAdjustmentFactor = reader.GetValue<decimal>("cntr_adj_factor_no");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }

            _seriLogger.Debug("Retrived contract adjustment factor {ContractAdjustmentFactor} for contract {ContractNumber}", contractAdjustmentFactor, contractNumber);
            return contractAdjustmentFactor;
        }

        public List<XElement> GetContractData(int contractNumber, DateTime renewalDate)
        {
            var results = new List<XElement>();

            try
            {
                _seriLogger.Information("Getting contract data for {ContractNumber} with renewal date {RenewalDate}", contractNumber, renewalDate.ToShortDateString());

                using (OracleConnection conn = new OracleConnection(_ModsConnectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"select
	                                            g.grp_no
	                                            ,mbd.contract_no
	                                            ,g.last_renewal_dt
	                                            ,person.state_cd as state_abrv
	                                            ,person.county_nm
	                                            ,person.zipcode_cd
	                                            ,zc.county_nm as default_county
	                                            ,subgrp.subgrp_nm
	                                            ,subgrp.subgrp_tp_id
	                                            ,gsp.mrkt_seg_id
	                                            ,gsp.lcnse_corp_id
	                                            ,gsp.delivery_network_id
	                                            ,gsp.grandfather_flg
	                                            ,gsp.gf_eff_dt
	                                            ,gsp.gf_end_dt
	                                            ,msd.mrkt_seg_desc as market_segment
	                                            ,bp.ben_pkg_cd
	                                            ,bp.ben_pkg_tp
	                                            ,bp.ben_pkg_tp_cd
	                                            ,bp.ben_pkg_hospice_flg
	                                            ,bp.ben_pkg_ped_dentl_flg
	                                            ,pd.lcnse_corp_id
	                                            ,pd.lcnsing_state
	                                            ,lcd.lcnse_corp_nm
	                                            ,lcd.lcnse_corp_abrv
	                                            ,gsite.site_id_no
                                            from mods.mbd mbd
                                            inner join mods.mbr_og2 mbr on mbd.contract_no = mbr.contract_no
	                                            and mbd.ph_person_no = mbr.person_no
	                                            and :renewaldate between mbr.eff_dt and mbr.end_dt
                                            inner join mods.person_ds person on mbr.person_no = person.person_no
                                            left join mods.zip_code_demographics_ds zc on person.state_cd = zc.state_cd
	                                            and substr(person.zipcode_cd, 1 ,5) = zc.zipcode_cd
                                            inner join mods.grp_ds g on g.grp_id = mbd.grp_id
                                            inner join mods.grp_subgrp_pkg_ds gsp on gsp.grp_id = mbd.grp_id
	                                            and gsp.subgrp_id = mbd.subgrp_id
	                                            and mbr.ben_pkg_id = gsp.ben_pkg_id
                                            inner join mods.gs1 subgrp on mbd.grp_id = subgrp.grp_id
	                                            and subgrp.subgrp_id = gsp.subgrp_id
                                            inner join adw.mrkt_seg_ds msd on gsp.mrkt_seg_id = msd.mrkt_seg_id
                                            inner join mods.ben_pkg_ds bp on bp.ben_pkg_id = gsp.ben_pkg_id
                                            inner join mods.prod_ds pd on pd.prod_id = gsp.prod_id
                                            inner join adw.lcnse_corp_ds lcd on pd.lcnse_corp_id = lcd.lcnse_corp_id
                                            inner join subgrp_ds gsite on subgrp.subgrp_id = gsite.subgrp_id
                                            where mbd.contract_no = :contractnumber
                                            and :renewaldate between gsp.eff_dt and gsp.end_dt";

                        cmd.BindByName = true;
                        // Replace all instances of cmd.AddParameter(...) with the following pattern:
                        cmd.Parameters.Add(new OracleParameter(":renewalDate", OracleDbType.Varchar2) { Value = renewalDate.Date.ToString("dd-MMM-yyyy") });
                        cmd.Parameters.Add(new OracleParameter(":contractNumber", OracleDbType.Varchar2) { Value = contractNumber });


                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                results.Add(reader.ToXml(METADATA_ELEMENT));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }

            _seriLogger.Debug("Retrieved {Count} records for contract data", results.Count);
            return results;
        }

        public List<XElement> GetCensusByContract(int contractNumber, DateTime renewalDate)
        {
            var results = new List<XElement>();

            try
            {
                _seriLogger.Information("Getting member census for contract {ContractNumber} with renewal date {RenewalDate}", contractNumber, renewalDate.ToShortDateString());
                using (OracleConnection conn = new OracleConnection(_ModsConnectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"select 
	                                            mbd.contract_no
	                                            ,person.last_nm
	                                            ,person.middle_nm
	                                            ,person.first_nm
	                                            ,person.birth_dt
	                                            ,person.external_person_id
	                                            ,person.gender_cd
	                                            ,person.state_cd
	                                            ,mbe.dsn_id
	                                            ,mbe.rel_to_ph
	                                            ,pcri.latest_tobacco_usage_cd as tobaccouse
	                                            ,pcri.latest_filed_dt as tobaccodate
	                                            ,rel_ds.rel_txt
	                                            ,count(bpm.ben_pkg_cd) medcount
	                                            ,count(bpd.ben_pkg_cd) dentcount
                                            from mods.grp_ds grp
                                            inner join mods.mbd mbd on grp.grp_id = mbd.grp_id
                                            inner join mods.mbe mbe on mbd.contract_no = mbe.contract_no
                                            inner join mods.person_ds person on person.person_no = mbe.person_no
                                            left join mods.person_cntr_rate_item_ds pcri  on pcri.person_no = person.person_no
	                                            and pcri.contract_no = mbe.contract_no
                                            left join adw.rel_ds on rel_ds.rel_cd = mbe.rel_to_ph
                                            left join mods.mbr_og2 og2 on mbe.person_no = og2.person_no
	                                            and mbe.contract_no = og2.contract_no
	                                            and :renewaldate between og2.eff_dt and og2.end_dt       
                                            left join mods.ben_pkg_ds bpm on og2.ben_pkg_id = bpm.ben_pkg_id
	                                            and bpm.ben_pkg_tp_cd = 'M'        
                                            left join mods.ben_pkg_ds bpd on og2.ben_pkg_id = bpd.ben_pkg_id
	                                            and bpd.ben_pkg_tp_cd = 'D'             
                                            where mbd.contract_no = :contractnumber
	                                            and :renewaldate between mbd.eff_dt and mbd.end_dt
	                                            and :renewaldate between mbe.eff_dt and mbe.end_dt
                                            group by 
	                                            mbd.contract_no
	                                            ,person.person_no
	                                            ,person.last_nm
	                                            ,person.middle_nm
	                                            ,person.first_nm
	                                            ,person.birth_dt
	                                            ,person.external_person_id
	                                            ,person.gender_cd
	                                            ,person.state_cd
	                                            ,mbe.dsn_id
	                                            ,mbe.rel_to_ph
	                                            ,pcri.latest_tobacco_usage_cd
	                                            ,	pcri.latest_filed_dt
	                                            ,rel_ds.rel_txt";

                        cmd.BindByName = true;
                        // Replace all instances of cmd.AddParameter(...) with the following pattern:
                        cmd.Parameters.Add(new OracleParameter(":renewalDate", OracleDbType.Varchar2) { Value = renewalDate.Date.ToString("dd-MMM-yyyy") });
                        cmd.Parameters.Add(new OracleParameter(":groupNumber", OracleDbType.Varchar2) { Value = contractNumber });


                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                results.Add(reader.ToXml(MEMBER_ELEMENT));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }

            _seriLogger.Debug("Retrieved {Count} records for census data", results.Count);
            return results;
        }

        public List<XElement> GetMedicalAttributes(string planId, DateTime effectiveDate)
        {
            var results = new List<XElement>();

            try
            {
                _seriLogger.Information("Getting medical attributes for {planId} with effective date {EffectiveDate}", planId, effectiveDate.ToShortDateString());
                using (OracleConnection conn = new OracleConnection(_ModsConnectionString))
                {
                    conn.Open();
                    using (OracleCommand cmd = conn.CreateCommand())
                    {
                        cmd.CommandText = @"select 
                                                qhp.qhp_hios_plan_id as planId
                                                ,g.grp_no as GroupNumber
                                                ,bp.ben_pkg_cd as PackageCode
                                                ,0 as SiteId
                                                ,'010' as ClinicCode
                                            from mods.qhp_id_dict_og2_ds qhp
                                            inner join mods.grp_ds g on qhp.grp_id = g.grp_id
                                            inner join mods.ben_pkg_ds bp on qhp.ben_pkg_id = bp.ben_pkg_id
                                            where qhp.qhp_hios_plan_id = :planId
                                                and :renewalDate between qhp.eff_dt and qhp.term_dt
                                                and qhp.DEL_FLG = 'N'
                                                and qhp.mrkt_seg_id <> 7";

                        cmd.BindByName = true;
                        // Replace all instances of cmd.AddParameter(...) with the following pattern:
                        cmd.Parameters.Add(new OracleParameter(":renewalDate", OracleDbType.Varchar2) { Value = effectiveDate.Date.ToString("dd-MMM-yyyy") });
                        cmd.Parameters.Add(new OracleParameter(":planId", OracleDbType.Varchar2) { Value = planId });


                        using (IDataReader reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                                results.Add(reader.ToXml(METADATA_ELEMENT));
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }

            _seriLogger
                .ForContext("Results", JsonConvert.SerializeObject(results, Formatting.Indented))
                .Debug("Retrieved {Count} records for group data", results.Count);
            return results;
        }


    }
}
