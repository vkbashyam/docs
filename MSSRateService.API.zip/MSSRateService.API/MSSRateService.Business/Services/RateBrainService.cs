﻿using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Extensions;
using MSSRateService.Common.Interfaces.Rate;
using MSSRateService.Domain.Models.RateBrain;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using MSSRateService.Common;

namespace MSSRateService.Business.Services
{
    public class RateBrainService : IRateBrainService
    {
        private readonly RateBrainContext _db;
        private readonly ILogger _log;

        public RateBrainService(RateBrainContext db, ILogger log)
        {
            _db = db;
            _log = log;
        }

        public List<PlanFactor> GetPlanFactors(Enums.CoverageType coverageType, string packageCode, DateTime renewalDate, string county, string state, int memberCount)
        {
            var unit = memberCount > 1 ? "F" : "S";

            if (coverageType == Enums.CoverageType.Medical)
            {
                try
                {
                    var planFactors = (from pp in _db.TblPlanPkg
                                       join pdn in _db.TblPlanDeliveryNetwork on pp.PlanCode equals pdn.PlanCode
                                       join ps in _db.TblPlanSet on pp.PlanCode equals ps.PlanCode
                                       join rps in _db.TblRiskPoolSet on ps.PlanSet equals rps.PlanSet
                                       join rc in _db.TblRateContainer on rps.RiskPoolSet equals rc.RiskPoolSet
                                       from cras in _db.TblCountyRateAreaSet.Where(m => m.CountyRateAreaSet == rps.CountyRateAreaSet && m.CountyName == county && m.State == state).DefaultIfEmpty()
                                       from ns in _db.TblNetworkSet.Where(m => m.NetworkSet == ps.NetworkSet && cras.RateArea == m.RateArea && pp.NetworkId == m.NetworkId).DefaultIfEmpty()
                                       from nsMax in _db.TblNetworkSet.Where(m => m.NetworkSet == ps.NetworkSet && ps.MaxRateArea == m.RateArea && pp.NetworkId == m.NetworkId).DefaultIfEmpty()
                                       from tas in _db.TblAreaSet.Where(m => ((ns.RateArea != null && ns.RateArea == m.RateArea) || (ns.RateArea == null && nsMax.RateArea == m.RateArea)) && rps.AreaSet == m.AreaSet).DefaultIfEmpty()
                                       where pp.PkgCode == packageCode
                                       && (pp.PkgEffDate <= renewalDate && pp.PkgEndDate >= renewalDate)
                                       && (pp.MacnetworkId == null || pp.MacnetworkId == pdn.MacnetworkId)
                                       && (pdn.MacnetworkEffDate <= renewalDate && pdn.MacnetworkEndDate >= renewalDate)
                                       && (ps.Unit == unit || ps.Unit == "B")
                                       && rc.RateContainerStatusId == 3
                                       && (rc.EffDate <= renewalDate && rc.EndDate >= renewalDate)
                                       select new PlanFactor
                                       {
                                           RiskPoolSet = rps.RiskPoolSet,
                                           RiskPoolBaseRate = rps.RiskPoolBaseRate,
                                           RiskPoolSubType = rps.RiskPoolSubType,
                                           DependentCountMethod = rps.DepCountMethod.ToString(),
                                           AgeBandSet = rps.AgeBandSet,
                                           Grandfathered = rps.Grandfathered,
                                           SingleFamilyUnitMethod = rps.SingFamUnitMethod,
                                           Unit = ps.Unit,
                                           PlanCode = pp.PlanCode,
                                           PackageCode = pp.PkgCode,
                                           NetworkId = pp.NetworkId,
                                           MacNetworkId = pp.MacnetworkId,
                                           PlanMarketingName = pp.PlanMarketingName,
                                           PlanSet = ps.PlanSet,
                                           MaxRateArea = ps.MaxRateArea,
                                           Factor = ps.PlanFactor,
                                           NetworkSet = ps.NetworkSet,
                                           AreaId = cras.AreaId,
                                           County = cras.CountyName,
                                           CountyRateAreaSet = cras.CountyRateAreaSet,
                                           RateArea = cras.RateArea,
                                           State = cras.State,
                                           NetworkFactor = ns.NetworkFactor,
                                           MaxNetworkId = nsMax.NetworkId,
                                           MaxNetworkFactor = nsMax.NetworkFactor,
                                           AreaFactorRateArea = tas.RateArea,
                                           AreaFactor = tas.AreaFactor
                                       }).ToList();

                    if (Debugger.IsAttached)
                        File.WriteAllText(@$"c:/users/{Environment.UserName}/desktop/planFactors.xml", planFactors.Serialize());

                    _log.ForContext("PlanFactors", planFactors.Serialize()).Debug("Retrieved Plan Factors");

                    return planFactors;
                }
                catch (Exception ex)
                {
                    _log.Exception(ex, "Unable to get plan factors");
                }
            }

            _log.Information("Plan factors are only available for medical coverages");
            return null;
        }

        public List<AgeBand> GetAgeBands(Enums.CoverageType coverageType, int ageBandSet)
        {
            if (coverageType == Enums.CoverageType.Medical)
            {
                try
                {
                    var ageBands = _db.TblAgeBandSet.Where(m => m.AgeBandSet == ageBandSet).Select(m => new AgeBand
                    {
                        AgeBandType = m.AgeBandType,
                        Description = m.AgeBandDesc,
                        MinimumAge = m.MinAge,
                        MaximumAge = m.MaxAge,
                        Gender = m.Gender,
                        AgeFactor = m.AgeFactor,
                        TobaccoFactor = m.TobaccoFactor,
                        HealthAndWellnessFactor = m.HealthAndWellnessFactor
                    }).ToList();

                    if (Debugger.IsAttached)
                        File.WriteAllText(@$"c:/users/{Environment.UserName}/desktop/ageBands.xml", ageBands.Serialize());

                    _log.ForContext("AgeBands", ageBands.Serialize()).Debug("Retrieved Age Bands");

                    return ageBands;
                }
                catch (Exception ex)
                {
                    _log.Exception(ex, "Unable to get age bands");
                }
            }

            _log.Warning("Age bands are only available for medical coverages");
            return null;
        }
    }
}
