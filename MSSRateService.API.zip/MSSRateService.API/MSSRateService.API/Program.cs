using Microsoft.EntityFrameworkCore;
using MSSRateService.Business.Services;
using MSSRateService.Common.Interfaces;
using MSSRateService.Common.Interfaces.Rate;
using MSSRateService.Domain.Models.ProcessLog;
using MSSRateService.Domain.Models.RateBrain;
using Serilog;

var builder = WebApplication.CreateBuilder(args);

// Logging (optional Serilog setup)
builder.Host.UseSerilog((ctx, lc) =>
    lc.WriteTo.Console()
      .ReadFrom.Configuration(ctx.Configuration));

// Services
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddControllers();

builder.Services.AddScoped<IRateService, RateService>();
builder.Services.AddScoped<IRateBrainService, RateBrainService>();
builder.Services.AddScoped<IModsService, ModsService>();
builder.Services.AddScoped<IProcessLogService, ProcessLogService>();

builder.Services.AddSingleton(Serilog.Log.Logger);

builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAnyOrigin", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyHeader()
              .AllowAnyMethod();
    });
});

builder.Services.AddDbContext<ProcessLogContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("ProcessLogEntities"));
});

builder.Services.AddDbContext<RateBrainContext>(options =>
{
    options.UseSqlServer(builder.Configuration.GetConnectionString("RateBrainEntities"));
});

var app = builder.Build();

// Middleware order
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(c =>
    {
        c.SwaggerEndpoint("/swagger/v1/swagger.json", "MSS Rate Service API v1");
        c.RoutePrefix = string.Empty; // Swagger at root
    });
}

app.UseHttpsRedirection();

app.UseCors("AllowAnyOrigin");

app.UseAuthorization();

app.MapControllers();

app.Run();
