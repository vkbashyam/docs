﻿using Microsoft.AspNetCore.Mvc;
using Serilog;
using System;
using System.Net;
using MSSRateService.Common;
using MSSRateService.Common.Interfaces.Rate;
using MSSRateService.Common.DataTransferObjects.Rate;
using MSSRateService.Common.Extensions;
using MSSRateService.Common.Interfaces.Rate;

namespace MSSRateService.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class RateController : ControllerBase
    {
        private readonly IRateService _rate;
        private readonly Serilog.ILogger _log;

        public RateController(IRateService rate, Serilog.ILogger log)
        {
            _rate = rate;
            _log = log;
        }

        [HttpGet, Route("ByGroup")]
        public IActionResult ByGroup(int groupNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            _log
                .ForContext("GroupNumber", groupNumber)
                .ForContext("RenewalDate", renewalDate)
                .ForContext("CoverageType", coverageType)
                .ForContext("PackageCode", packageCode)
                .Information("New Rate Request By Group");

            RateRequest request;
            try
            {
                request = _rate.RateRequestByGroup(groupNumber, renewalDate, coverageType, packageCode);
            }
            catch
            {
                return Ok("Unable to get rates by group");
            }

            return new ContentResult
            {
                Content = request.Serialize(),
                ContentType = "application/xml",
                StatusCode = (int)HttpStatusCode.OK
            };
        }

        [HttpGet, Route("ByContract")]
        public IActionResult ByContract(int contractNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            _log
                .ForContext("ContractNumber", contractNumber)
                .ForContext("RenewalDate", renewalDate)
                .ForContext("CoverageType", coverageType)
                .ForContext("PackageCode", packageCode)
                .Information("New Rate Request By Contract");

            RateRequest request;
            try
            {
                request = _rate.RateRequestByContract(contractNumber, renewalDate, coverageType, packageCode);
            }
            catch (Exception ex)
            {
                return Ok($"Unable to get rates by contract\n{ex}");
            }

            return new ContentResult
            {
                Content = request.Serialize(),
                ContentType = "application/xml",
                StatusCode = (int)HttpStatusCode.OK
            };
        }

        [HttpGet, Route("ByCensus")]
        public IActionResult ByCensus([FromBody] CensusRequest census, string state, string county, string zip, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode)
        {
            _log
                .ForContext("Census", census)
                .ForContext("State", state)
                .ForContext("County", county)
                .ForContext("Zip", zip)
                .ForContext("RenewalDate", renewalDate)
                .ForContext("CoverageType", coverageType)
                .ForContext("PackageCode", packageCode)
                .Information("New Rate Request By Contract");

            RateRequest request;
            try
            {
                request = _rate.RateRequestByCensus(census, state, county, zip, renewalDate, coverageType, packageCode);
            }
            catch
            {
                return Ok("Unable to get rates by census");
            }

            return new ContentResult
            {
                Content = request.Serialize(),
                ContentType = "application/xml",
                StatusCode = (int)HttpStatusCode.OK
            };
        }
    }
}
