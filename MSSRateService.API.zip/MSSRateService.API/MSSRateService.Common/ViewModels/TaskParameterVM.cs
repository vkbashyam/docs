﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSSRateService.Common.ViewModels
{
    public class TaskParameterVM
    {
        public int TaskParameterId { get; set; }

        public int TaskParameterTypeId { get; set; }

        [DisplayName("Parameter Data Type")]
        public string TaskParameterTypeName { get; set; }

        [DisplayName("Parameter Name")]
        public string TaskParameterName { get; set; }

        public string TaskParameterValue { get; set; }

        public int? Minimum { get; set; }

        public int? Maximum { get; set; }
    }
}
