﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSSRateService.Common.ViewModels
{
    public class TransactionVM
    {
        [DisplayName("ID")]
        public int TransactionId { get; set; }

        public int TaskStateRegionId { get; set; }

        public int TaskId { get; set; }

        [DisplayName("Task")]
        public string TaskName { get; set; }
        public int StateId { get; set; }
        [DisplayName("State")]
        public string StateName { get; set; }
        public int? RegionId { get; set; }
        [DisplayName("Region")]
        public string RegionName { get; set; }

        [DisplayName("ProcessedBy")]
        public string ProcessBy { get; set; }
        public int StatusId { get; set; }
        [DisplayName("Status")]
        public string StatusName { get; set; }
        public string Log { get; set; }
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy hh:mm}")]
        public DateTime Start { get; set; }
        [DisplayFormat(DataFormatString = "{0:MM/dd/yyyy hh:mm}")]
        public DateTime? End { get; set; }
        public int TransactionCount { get; set; }
        public List<TaskParameterVM> TaskParameters { get; set; }

        public string StartStr
        {
            get
            {
                return Start.ToString("MM/dd/yyyy hh:mm tt");
            }
        }

        public string EndStr
        {
            get
            {
                if (End != null)
                    return End.Value.ToString("MM/dd/yyyy hh:mm tt");

                return string.Empty;
            }
        }

        public string Duration
        {
            get
            {
                var duration = string.Empty;
                if (End == null)
                    return duration;

                duration = End.Value.Subtract(Start).ToString(@"hh\:mm\:ss");
                //TimeSpan span = End.Value - Start;

                //if (span.Hours > 0)
                //    duration += $"{span.Hours} {(span.Hours == 1 ? "Hour" : "Hours")} ";
                //if (span.Minutes > 0)
                //    duration += $"{span.Minutes} {(span.Minutes == 1 ? "Minute" : "Minutes")} ";
                //if (span.Seconds > 0)
                //    duration += $"{span.Seconds} {(span.Seconds == 1 ? "Second" : "Seconds")}";

                return duration;
            }
        }
    }
}
