﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSSRateService.Common.ViewModels
{
    public class TaskStateRegionVM
    {
        public int TaskStateRegionId { get; set; }
        public int StateId { get; set; }
        public int? RegionId { get; set; }
        public string StateName { get; set; }
        public string RegionName { get; set; }
    }
}
