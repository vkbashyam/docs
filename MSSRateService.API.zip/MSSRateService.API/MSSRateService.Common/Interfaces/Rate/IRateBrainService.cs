﻿using MSSRateService.Common.DataTransferObjects.Rate;
using System;
using System.Collections.Generic;

namespace MSSRateService.Common.Interfaces.Rate
{
    public interface IRateBrainService
    {
        List<PlanFactor> GetPlanFactors(Enums.CoverageType coverageType, string packageCode, DateTime renewalDate, string county, string state, int memberCount);
        List<AgeBand> GetAgeBands(Enums.CoverageType coverageType, int ageBandSet);
    }
}
