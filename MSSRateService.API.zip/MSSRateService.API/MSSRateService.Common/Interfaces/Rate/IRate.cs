﻿using MSSRateService.Common.DataTransferObjects.Rate;

namespace MSSRateService.Common.Interfaces.Rate
{
    public interface IRate
    {
        bool UpdateAgeBands(RateRequest request);
        bool UpdateFamilyRate(RateRequest request);
    }
}
