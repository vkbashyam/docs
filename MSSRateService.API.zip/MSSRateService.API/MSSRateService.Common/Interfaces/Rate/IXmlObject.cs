﻿namespace MSSRateService.Common.Interfaces.Rate
{
    public interface IXmlSerializedObject
    {
    }
}
