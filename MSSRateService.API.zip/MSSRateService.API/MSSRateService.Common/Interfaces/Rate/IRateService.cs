﻿using MSSRateService.Common.DataTransferObjects.Rate;
using System;
namespace MSSRateService.Common.Interfaces.Rate
{
    public interface IRateService
    {
        RateRequest RateRequestByGroup(int groupNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode);
        RateRequest RateRequestByContract(int contractNumber, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode);
        RateRequest RateRequestByCensus(CensusRequest census, string state, string county, string zip, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode);
    }
}
