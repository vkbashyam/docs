﻿using MSSRateService.Common.DataTransferObjects.Rate;
using System;

namespace MSSRateService.Common.Interfaces.Rate
{
    public interface IRateRequest
    {
        RateRequest CreateRateRequest(int id, DateTime renewalDate, Enums.CoverageType coverageType, string packageCode);    
        bool CalculateRateRequest(RateRequest request);
    }
}
