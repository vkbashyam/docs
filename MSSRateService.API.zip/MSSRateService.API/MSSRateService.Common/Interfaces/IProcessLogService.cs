﻿using MSSRateService.Common.DataTransferObjects;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;

namespace MSSRateService.Common.Interfaces
{
    public interface IProcessLogService
    {
        int Log(int processId, int statusId, string assembly, string version, string jsonData, HttpResponseDto response);
        int Log(int processId, int statusId, string assembly, string version, JObject json);
        IEnumerable<LogDto> GetLogs(int processId, int transactionId, DateTime start, DateTime? end);
    }
}
