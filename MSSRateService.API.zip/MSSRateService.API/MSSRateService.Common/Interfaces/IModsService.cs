﻿using System;
using System.Collections.Generic;
using System.Xml.Linq;

namespace MSSRateService.Common.Interfaces
{
    public interface IModsService
    {
        List<XElement> GetGroupData(int groupNumber, DateTime renewalDate);
        List<XElement> GetCensusByGroup(int groupNumber, DateTime renewalDate);
        List<XElement> GetMemberPlans(int groupNumber, DateTime renewalDate);
        decimal GetContractAdjustmentFactorByContract(int contractNumber);
        List<XElement> GetContractData(int contractNumber, DateTime renewalDate);
        List<XElement> GetCensusByContract(int contractNumber, DateTime renewalDate);
        List<XElement> GetMedicalAttributes(string hiosPlanId, DateTime effectiveDate);
    }
}
