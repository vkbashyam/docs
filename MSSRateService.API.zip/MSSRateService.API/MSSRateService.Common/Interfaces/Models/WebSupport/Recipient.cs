﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class Recipient
    {
        public Recipient()
        {
            NotificationRecipient = new HashSet<NotificationRecipient>();
        }

        [Key]
        public int RecipientId { get; set; }
        [Required]
        [StringLength(255)]
        public string Email { get; set; }
        public bool IsVariable { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreatedOn { get; set; }

        [InverseProperty("Recipient")]
        public virtual ICollection<NotificationRecipient> NotificationRecipient { get; set; }
    }
}
