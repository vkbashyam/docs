﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class Document
    {
        public Document()
        {
            NotificationDocument = new HashSet<NotificationDocument>();
        }

        [Key]
        public int DocumentId { get; set; }
        [Required]
        [StringLength(255)]
        public string Name { get; set; }
        [StringLength(255)]
        public string Link { get; set; }
        [Required]
        public byte[] Bytes { get; set; }
        [Required]
        [StringLength(255)]
        public string MediaType { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreatedOn { get; set; }
        [Column(TypeName = "date")]
        public DateTime EffectiveDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }

        [InverseProperty("Document")]
        public virtual ICollection<NotificationDocument> NotificationDocument { get; set; }
    }
}
