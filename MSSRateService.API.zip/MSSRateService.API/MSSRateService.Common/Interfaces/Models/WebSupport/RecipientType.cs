﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class RecipientType
    {
        public RecipientType()
        {
            NotificationRecipient = new HashSet<NotificationRecipient>();
        }

        [Key]
        public int RecipientTypeId { get; set; }
        [Required]
        [StringLength(100)]
        public string Type { get; set; }

        [InverseProperty("RecipientType")]
        public virtual ICollection<NotificationRecipient> NotificationRecipient { get; set; }
    }
}
