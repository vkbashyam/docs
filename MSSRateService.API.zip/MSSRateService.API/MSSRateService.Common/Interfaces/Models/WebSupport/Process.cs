﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class Process
    {
        public Process()
        {
            ProcessNotificationOrder = new HashSet<ProcessNotificationOrder>();
        }

        [Key]
        public int ProcessId { get; set; }
        [Required]
        [StringLength(255)]
        public string Name { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreatedOn { get; set; }
        [Required]
        public bool? IsActive { get; set; }

        [InverseProperty("Process")]
        public virtual ICollection<ProcessNotificationOrder> ProcessNotificationOrder { get; set; }
    }
}
