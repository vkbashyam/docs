﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class Notification
    {
        public Notification()
        {
            NotificationDocument = new HashSet<NotificationDocument>();
            NotificationRecipient = new HashSet<NotificationRecipient>();
            NotificationResource = new HashSet<NotificationResource>();
            ProcessNotificationOrder = new HashSet<ProcessNotificationOrder>();
        }

        [Key]
        public int NotificationId { get; set; }
        [Required]
        [StringLength(255)]
        public string Name { get; set; }
        [Required]
        [StringLength(255)]
        public string Subject { get; set; }
        public string Message { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreatedOn { get; set; }
        [Column(TypeName = "date")]
        public DateTime EffectiveDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }

        [InverseProperty("Notification")]
        public virtual ICollection<NotificationDocument> NotificationDocument { get; set; }
        [InverseProperty("Notification")]
        public virtual ICollection<NotificationRecipient> NotificationRecipient { get; set; }
        [InverseProperty("Notification")]
        public virtual ICollection<NotificationResource> NotificationResource { get; set; }
        [InverseProperty("Notification")]
        public virtual ICollection<ProcessNotificationOrder> ProcessNotificationOrder { get; set; }
    }
}
