﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class NotificationDocument
    {
        [Key]
        public int NotificationDocumentId { get; set; }
        public int NotificationId { get; set; }
        public int DocumentId { get; set; }

        [ForeignKey(nameof(DocumentId))]
        [InverseProperty("NotificationDocument")]
        public virtual Document Document { get; set; }
        [ForeignKey(nameof(NotificationId))]
        [InverseProperty("NotificationDocument")]
        public virtual Notification Notification { get; set; }
    }
}
