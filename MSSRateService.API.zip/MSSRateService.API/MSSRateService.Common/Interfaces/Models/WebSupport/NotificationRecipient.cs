﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class NotificationRecipient
    {
        [Key]
        public int NotificationRecipientId { get; set; }
        public int NotificationId { get; set; }
        public int RecipientId { get; set; }
        public int RecipientTypeId { get; set; }

        [ForeignKey(nameof(NotificationId))]
        [InverseProperty("NotificationRecipient")]
        public virtual Notification Notification { get; set; }
        [ForeignKey(nameof(RecipientId))]
        [InverseProperty("NotificationRecipient")]
        public virtual Recipient Recipient { get; set; }
        [ForeignKey(nameof(RecipientTypeId))]
        [InverseProperty("NotificationRecipient")]
        public virtual RecipientType RecipientType { get; set; }
    }
}
