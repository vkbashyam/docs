﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class NotificationResource
    {
        [Key]
        public int NotificationResourceId { get; set; }
        public int NotificationId { get; set; }
        public int ResourceId { get; set; }

        [ForeignKey(nameof(NotificationId))]
        [InverseProperty("NotificationResource")]
        public virtual Notification Notification { get; set; }
        [ForeignKey(nameof(ResourceId))]
        [InverseProperty("NotificationResource")]
        public virtual Resource Resource { get; set; }
    }
}
