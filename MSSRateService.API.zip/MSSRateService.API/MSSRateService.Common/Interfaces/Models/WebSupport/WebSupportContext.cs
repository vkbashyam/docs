﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class WebSupportContext : DbContext
    {
        public WebSupportContext()
        {
        }

        public WebSupportContext(DbContextOptions<WebSupportContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Document> Document { get; set; }
        public virtual DbSet<DocumentOutput> DocumentOutput { get; set; }
        public virtual DbSet<Notification> Notification { get; set; }
        public virtual DbSet<NotificationDocument> NotificationDocument { get; set; }
        public virtual DbSet<NotificationRecipient> NotificationRecipient { get; set; }
        public virtual DbSet<NotificationResource> NotificationResource { get; set; }
        public virtual DbSet<Process> Process { get; set; }
        public virtual DbSet<ProcessNotificationOrder> ProcessNotificationOrder { get; set; }
        public virtual DbSet<Recipient> Recipient { get; set; }
        public virtual DbSet<RecipientType> RecipientType { get; set; }
        public virtual DbSet<Resource> Resource { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("server=SPHPASG0209J7J\\MSSQLSERVER19;database=WebSupport;Integrated Security=True;");
//            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Document>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Link).IsUnicode(false);

                entity.Property(e => e.MediaType).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<DocumentOutput>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.JsonFormat).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<Notification>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Message).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);

                entity.Property(e => e.Subject).IsUnicode(false);
            });

            modelBuilder.Entity<NotificationDocument>(entity =>
            {
                entity.HasOne(d => d.Document)
                    .WithMany(p => p.NotificationDocument)
                    .HasForeignKey(d => d.DocumentId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Notificat__Docum__3E52440B");

                entity.HasOne(d => d.Notification)
                    .WithMany(p => p.NotificationDocument)
                    .HasForeignKey(d => d.NotificationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Notificat__Notif__3D5E1FD2");
            });

            modelBuilder.Entity<NotificationRecipient>(entity =>
            {
                entity.HasOne(d => d.Notification)
                    .WithMany(p => p.NotificationRecipient)
                    .HasForeignKey(d => d.NotificationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Notificat__Notif__45F365D3");

                entity.HasOne(d => d.Recipient)
                    .WithMany(p => p.NotificationRecipient)
                    .HasForeignKey(d => d.RecipientId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Notificat__Recip__46E78A0C");

                entity.HasOne(d => d.RecipientType)
                    .WithMany(p => p.NotificationRecipient)
                    .HasForeignKey(d => d.RecipientTypeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Notificat__Recip__47DBAE45");
            });

            modelBuilder.Entity<NotificationResource>(entity =>
            {
                entity.HasOne(d => d.Notification)
                    .WithMany(p => p.NotificationResource)
                    .HasForeignKey(d => d.NotificationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Notificat__Notif__35BCFE0A");

                entity.HasOne(d => d.Resource)
                    .WithMany(p => p.NotificationResource)
                    .HasForeignKey(d => d.ResourceId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Notificat__Resou__36B12243");
            });

            modelBuilder.Entity<Process>(entity =>
            {
                entity.HasIndex(e => e.Name)
                    .HasDatabaseName("UQ__Process__737584F6C1094F7B")
                    .IsUnique();

                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.IsActive).HasDefaultValueSql("((1))");

                entity.Property(e => e.Name).IsUnicode(false);
            });

            modelBuilder.Entity<ProcessNotificationOrder>(entity =>
            {
                entity.HasIndex(e => new { e.ProcessId, e.Order })
                    .HasDatabaseName("UQ__ProcessN__DD4394D19CFAFCA8")
                    .IsUnique();

                entity.HasOne(d => d.Notification)
                    .WithMany(p => p.ProcessNotificationOrder)
                    .HasForeignKey(d => d.NotificationId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ProcessNo__Notif__2E1BDC42");

                entity.HasOne(d => d.Process)
                    .WithMany(p => p.ProcessNotificationOrder)
                    .HasForeignKey(d => d.ProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__ProcessNo__Proce__2D27B809");
            });

            modelBuilder.Entity<Recipient>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Email).IsUnicode(false);
            });

            modelBuilder.Entity<RecipientType>(entity =>
            {
                entity.Property(e => e.Type).IsUnicode(false);
            });

            modelBuilder.Entity<Resource>(entity =>
            {
                entity.Property(e => e.CreatedOn).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.Link).IsUnicode(false);

                entity.Property(e => e.MediaType).IsUnicode(false);

                entity.Property(e => e.Name).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
