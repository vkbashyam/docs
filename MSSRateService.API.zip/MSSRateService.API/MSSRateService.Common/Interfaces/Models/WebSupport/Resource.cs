﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class Resource
    {
        public Resource()
        {
            NotificationResource = new HashSet<NotificationResource>();
        }

        [Key]
        public int ResourceId { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [StringLength(100)]
        public string Link { get; set; }
        public byte[] Bytes { get; set; }
        [Required]
        [StringLength(255)]
        public string MediaType { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreatedOn { get; set; }
        [Column(TypeName = "date")]
        public DateTime EffectiveDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }

        [InverseProperty("Resource")]
        public virtual ICollection<NotificationResource> NotificationResource { get; set; }
    }
}
