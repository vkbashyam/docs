﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.WebSupport
{
    public partial class ProcessNotificationOrder
    {
        [Key]
        public int ProcessNotificationOrderId { get; set; }
        public int ProcessId { get; set; }
        public int NotificationId { get; set; }
        public int Order { get; set; }

        [ForeignKey(nameof(NotificationId))]
        [InverseProperty("ProcessNotificationOrder")]
        public virtual Notification Notification { get; set; }
        [ForeignKey(nameof(ProcessId))]
        [InverseProperty("ProcessNotificationOrder")]
        public virtual Process Process { get; set; }
    }
}
