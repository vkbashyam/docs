﻿using Microsoft.EntityFrameworkCore;

namespace MSSRateService.Domain.Models.MODS
{
    public class ModsContext : DbContext
    {
        public ModsContext(DbContextOptions<ModsContext> options) : base(options)
        {

        }
    }
}
