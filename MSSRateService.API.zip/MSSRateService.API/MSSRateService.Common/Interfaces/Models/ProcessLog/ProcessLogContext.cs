﻿using Microsoft.EntityFrameworkCore;

#nullable disable

namespace MSSRateService.Domain.Models.ProcessLog
{
    public partial class ProcessLogContext : DbContext
    {
        public ProcessLogContext()
        {
        }

        public ProcessLogContext(DbContextOptions<ProcessLogContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Log> Logs { get; set; }
        public virtual DbSet<Process> Processes { get; set; }
        public virtual DbSet<Status> Statuses { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
//                optionsBuilder.UseSqlServer("server=HPMSSSQLDEV;database=ProcessLog;user id =WebSQLAccount;password=Fas270!HP;");
//            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Log>(entity =>
            {
                entity.Property(e => e.Assembly).IsUnicode(false);

                entity.Property(e => e.Version).IsUnicode(false);

                entity.HasOne(d => d.Process)
                    .WithMany(p => p.Logs)
                    .HasForeignKey(d => d.ProcessId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Log__ProcessId__35BCFE0A");

                entity.HasOne(d => d.Status)
                    .WithMany(p => p.Logs)
                    .HasForeignKey(d => d.StatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Log__StatusId__37A5467C");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
