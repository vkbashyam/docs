﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace MSSRateService.Domain.Models.ProcessLog
{
    [Table("Log")]
    public partial class Log
    {
        [Key]
        public int LogId { get; set; }
        public int ProcessId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime TimeStamp { get; set; }
        [StringLength(100)]
        public string Assembly { get; set; }
        [StringLength(100)]
        public string Version { get; set; }
        public int StatusId { get; set; }
        public string JsonData { get; set; }

        [ForeignKey(nameof(ProcessId))]
        [InverseProperty("Logs")]
        public virtual Process Process { get; set; }
        [ForeignKey(nameof(StatusId))]
        [InverseProperty("Logs")]
        public virtual Status Status { get; set; }
    }
}
