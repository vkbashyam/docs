﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace MSSRateService.Domain.Models.ProcessLog
{
    [Table("Process")]
    public partial class Process
    {
        public Process()
        {
            Logs = new HashSet<Log>();
        }

        [Key]
        public int ProcessId { get; set; }
        [Required]
        [StringLength(100)]
        public string Name { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime CreateDate { get; set; }

        [InverseProperty(nameof(Log.Process))]
        public virtual ICollection<Log> Logs { get; set; }
    }
}
