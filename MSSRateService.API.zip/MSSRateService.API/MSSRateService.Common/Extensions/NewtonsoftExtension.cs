﻿using MSSRateService.Common.Helpers;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace MSSRateService.Common.Extensions
{
    public static class NewtonsoftExtension
    {
        public static void AddRange(this JObject obj, string json, string prefix = "")
        {
            var keyValuePairs = JsonHelper.FlattenJsonStructure(json, prefix);
            JObject jObj = JObject.Parse(JsonConvert.SerializeObject(keyValuePairs));

            foreach (var child in jObj.Children())
            {
                obj.Add(child);
            }
        }
    }
}
