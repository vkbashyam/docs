﻿using System;
using System.Data;
using System.Xml.Linq;

namespace MSSRateService.Common.Extensions
{
    public static class DbExtension
    {
        public static XElement ToXml(this IDataReader reader, string name)
        {
            var xml = new XElement(name);
            var columns = reader.GetSchemaTable();
            var columnReader = columns.CreateDataReader();

            while (columnReader.Read())
            {
                var key = columnReader.GetValue<string>("ColumnName");
                var value = reader.GetValue(columnReader.GetValue<int>("ColumnOrdinal"));
                var dataType = columnReader["DataType"];

                if (!(value is DBNull) && (Type)dataType == typeof(DateTime))
                    value = ((DateTime)value).ToString("MM/dd/yyyy");

                xml.Add(new XElement(key, value));
            }

            return xml;
        }

        public static T GetValue<T>(this IDataReader reader, string name)
        {
            try
            {
                object value = reader[name];
                Type type = typeof(T);
                type = Nullable.GetUnderlyingType(type) ?? type;

                if (value == null || DBNull.Value.Equals(value))
                    return default(T);

                return (T)Convert.ChangeType(value, type);
            }
            catch (Exception ex)
            {
                throw new Exception($"Failed to read value for {name} from data reader", ex);
            }
        }
    }
}
