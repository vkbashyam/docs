﻿using Aspose.Pdf.Drawing;
//using Aspose.Pdf.Operators;
using MSSRateService.Common.Interfaces.Rate;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Linq;
using System.Xml.Serialization;
using System.Xml.XPath;

namespace MSSRateService.Common.Extensions
{
    public static class XmlExtensions
    {
        public static XElement GetElementByName(this XElement element, string name)
        {
            var result = element.Element(name);

            //if null check upper case variant
            if (result == null)
                result = element.Element(name?.ToUpper());

            //if still null check lower case variant
            if (result == null)
                result = element.Element(name?.ToLower());

            return result;
        }

        public static string GetElementValueByName(this XElement element, string name)
        {
            return GetElementByName(element, name)?.Value;
        }

        public static string GetElementValueByName(this List<XElement> element, string name)
        {
            return GetElementByName(element, name)?.Value;
        }

        public static string Serialize(this IXmlSerializedObject obj)
        {
            var xml = string.Empty;
            var xmlSerializer = new XmlSerializer(obj.GetType());

            using (var sw = new StringWriterUTF8())
            {
                var ns = new XmlSerializerNamespaces();
                ns.Add(string.Empty, string.Empty);
                xmlSerializer.Serialize(sw, obj, ns);
                xml = sw.ToString();
            }

            return xml.CleanXml();
        }

        public static string Serialize<T>(this T obj)
        {
            var xml = string.Empty;
            var xmlSerializer = new XmlSerializer(typeof(T));

            using (var sw = new StringWriterUTF8())
            {
                var ns = new XmlSerializerNamespaces();
                ns.Add(string.Empty, string.Empty);
                xmlSerializer.Serialize(sw, obj, ns);
                xml = sw.ToString();
            }

            return xml.CleanXml();
        }

        public static string Serialize(this IEnumerable<IXmlSerializedObject> obj)
        {
            var objType = obj.GetType().GenericTypeArguments[0].Name;
            var xml = string.Empty;
            var xmlSerializer = new XmlSerializer(obj.GetType(), new XmlRootAttribute($"{objType}Collection"));

            using (var sw = new StringWriterUTF8())
            {
                var ns = new XmlSerializerNamespaces();
                ns.Add(string.Empty, string.Empty);
                xmlSerializer.Serialize(sw, obj, ns);
                xml = sw.ToString();
            }

            return xml.CleanXml();
        }

        private static string CleanXml(this string xml)
        {
            //var pattern = @"<\w+\s+\w+:nil=""true""(\s+xmlns:\w+=""http://www.w3.org/2001/XMLSchema-instance"")?\s*/>(\r\n)";
            var pattern = @"\w+:nil=""true""(\s+xmlns:\w+=""http://www.w3.org/2001/XMLSchema-instance"")?\s";
            var options = RegexOptions.Compiled | RegexOptions.IgnoreCase | RegexOptions.IgnorePatternWhitespace | RegexOptions.Multiline;

            var cleanXml = Regex.Replace(xml, pattern, string.Empty, options);

            return cleanXml;
        }

        public static List<XElement> GetElements(this XElement doc)
        {
            return GetElementsValue(doc);
        }

        private static List<XElement> GetElementsValue(this XContainer xml)
        {
            var elements = new List<XElement>();
            foreach (var ele in xml.Elements())
            {
                elements.Add(ele);
            }

            return elements;
        }

        public static List<XElement> GetElementsByName(this XDocument doc, string name)
        {
            var elements = doc.XPathSelectElements(name);
            if (elements == null) { return null; }

            return elements.ToList();
        }

        public static List<XElement> GetElementsByName(this XElement root, string name)
        {
            var elements = root.XPathSelectElements(name).ToList();
            return elements;
        }

        public static XElement GetElementByName(this List<XElement> ele, string name)
        {
            return ele.FirstOrDefault(m => m.Name.LocalName == name);
        }

        public static List<XElement> GetElements(this List<XElement> list)
        {
            return list.Elements().ToList();
        }

        public static XDocument ToXDocument(this XmlDocument xmlDocument)
        {
            using (var nodeReader = new XmlNodeReader(xmlDocument))
            {
                nodeReader.MoveToContent();
                return XDocument.Load(nodeReader);
            }
        }
    }

    public class StringWriterUTF8 : StringWriter
    {
        public override Encoding Encoding => Encoding.UTF8;
    }
}
