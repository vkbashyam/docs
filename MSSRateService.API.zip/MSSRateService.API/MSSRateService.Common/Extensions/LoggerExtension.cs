﻿using Serilog;
using System;

namespace MSSRateService.Common.Extensions
{
    public static class LoggerExtension
    {
        public static void Exception(this ILogger log, Exception ex, string msg = "")
        {
            log
                .ForContext("Exception", ex)
                .Warning(!string.IsNullOrEmpty(msg) ? msg : "Exception occured");
        }
    }
}
