﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSSRateService.Common.Filters
{
    public class SetSession : ActionFilterAttribute
    {
        private const string SESSION_SMALLGROUP_KEY = "InSmallGroupRole";
        private const string SESSION_INDIVIDUAL_KEY = "InIndividualRole";

        public string[] SmallGroupRoles;
        public string[] IndividualRoles;

        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (string.IsNullOrEmpty(context.HttpContext.Session.GetString(SESSION_SMALLGROUP_KEY)))
            {
                bool inRole = false;
                foreach (var group in SmallGroupRoles)
                    if (context.HttpContext.User.IsInRole(group))
                        inRole = true;

                context.HttpContext.Session.SetInt32(SESSION_SMALLGROUP_KEY, Convert.ToInt32(inRole));
            }

            if (string.IsNullOrEmpty(context.HttpContext.Session.GetString(SESSION_INDIVIDUAL_KEY)))
            {
                bool inRole = false;
                foreach (var group in IndividualRoles)
                    if (context.HttpContext.User.IsInRole(group))
                        inRole = true;

                context.HttpContext.Session.SetInt32(SESSION_INDIVIDUAL_KEY, Convert.ToInt32(inRole));
            }
        }
    }
}
