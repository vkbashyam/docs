﻿namespace MSSRateService.Common
{
    public class Enums
    {
        public enum Boolean
        {
            TRUE = 1,
            FALSE = 0
        }

        public enum MarketSegment
        {
            //Individual = 0, //on-prem
            //Small_Group = 1, //on-prem
            //Large_Group = 2, //on-prem
            Small_Group = 100000001,
            Large_Group = 100000000
        }

        public enum Filter
        {
            HCSS,
            Broker,
            Member
        }

        public enum Process
        {
            Preview,
            Production
        }

        public enum Status
        {
            Completed,
            Error
        }

        public enum HttpResponseDtoStatus
        {
            New,
            Replace
        }

        public enum LogLevel
        {
            Debug,
            Info,
            Warn,
            Error,
            Fatal
        }

        public enum CoverageType
        {
            Medical,
            Dental
        }

        public enum ProcessLogStatus
        {
            Success = 1,
            Error = 2,
            Warning = 3
        }

        public enum ProcessLogProcess
        {
            Group_Size_Verification = 1,
            SBC = 2,
            Proposal_Audit = 3,
            Proposal_Eligiblity = 4,
            Proposal_Renew_Web = 5,
            Load_Renewing_Groups = 6,
            Group_Size_Verification_Broker = 7,
            Group_Size_Verification_Results = 8,
            ACH_Validation = 9,
            Eligibility_Review = 10,
            Eligibility_Termination = 11
        }

        public enum SalesStage
        {
            Universe = 100000000,
            Initiated = 100000002,
            Quote_Creation_LG = 100000005,
            Underwriting = 100000006,
            Quote_Creation = 100000007,
            Proposal_Sent = 100000008,
            Account_Management = 100000003,
            Renewal_Initiated = 100000004,
            Renewal_Underwriting = 100000006,
            Renewal_Loaded = 100000010,
            Renewal_Generated = 100000011
        }

        public enum SalesStatus
        {
            Universe = 100000000,
            Request_Preliminary_Quote = 100000002,
            Request_Rated_Quote = 100000005,
            Pending_Clean_File = 100000004,
            Preliminary_Quote_Sent = 100000003,
            Review = 100000006,
            Pending_Missing_Info = 100000007,
            Pending_Phone_Call = 100000008,
            Underwritten = 100000009,
            Declined_to_Quote_DTQ = 100000010,
            Preparing_Quote = 100000011,
            Sales_Rework_DTQ = 100000012,
            Rate_Adjustment = 100000013,
            Proposal_Generated = 100000014,
            Pending_Decision = 100000015,
            Discovery_Discussion = 100000033,
            Account_Management = 100000017,
            In_Process = 100000018,
            Pre_Renewal_Issue = 100000019,
            Renewal_Underwriting = 100000020,
            Ready = 100000021,
            Pending_Audit = 100000022,
            Exception = 100000024,
            Not_Released = 100000025,
            CARS_Support = 100000026,
            Broker_PDF_to_Web = 100000028,
            Group_PDF_Created = 100000029,
            Withdraw_Renewal = 100000027,
            Manual_Renewal_Created = 100000023,
            Preparing_Quote_LG = 100000030,
            RVF_Sent = 100000031,
            Renewal_Issue_Pending = 100000032
        }

        public enum RenewalNoteDescription
        {
            ACA_Group_Size = 100000005,
            Zero_Contracts_Dental = 100000000,
            Zero_Contracts_Medical = 100000001,
            OOS_Address_Dental = 100000009,
            OOS_Address_Medical = 100000010,
            //OOS_Watch_State = 100000008,
            //Too_Many_OOS_Members_Medical = 100000029,
            One_Contract_Dental = 100000003,
            One_Contract_Medical = 100000004,
            One_To_Two_Contract_Medical = 100000002,
            Two_Contracts_Medical = 100000036,
            Eligibility_Review_Medical = 100000007
        }

        public enum PlanType
        {
            Medical = 100000000,
            Dental = 100000001
        }

        public enum GsvStatus
        {
            GSV_to_Group = 100000000,
            GSV_Returned_from_Group = 100000001,
            GSV_to_UW = 100000002,
            GSV_UW_Decision = 100000003,
            No_GSV_from_Group = 100000004
        }

        public enum TransactionStatus
        {
            Processing = 1,
            Complete = 2,
            Failed = 3
        }

        public enum TaskParameterType
        {
            String = 1,
            Number = 2,
            Boolean = 3,
            List = 4,
            Date = 5,
            Computed = 6
        }

        public enum TaskRole
        {
            Small_Group = 1,
            Individual = 2
        }

        public enum RecipientType
        {
            To = 1,
            Cc = 2,
            Bcc = 3,
            From = 4,
        }
    }
}