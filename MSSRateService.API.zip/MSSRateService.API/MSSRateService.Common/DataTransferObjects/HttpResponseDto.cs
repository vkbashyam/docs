﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace MSSRateService.Common.DataTransferObjects
{
    public class HttpResponseDto
    {
        private string _Message = string.Empty;
        private string _Status = string.Empty;
        private Dictionary<string, string[]> _Errors = new Dictionary<string, string[]>();

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public Dictionary<string, string[]> Errors
        {
            get
            {
                if (_Errors.Count == 0)
                    return null;

                return _Errors;
            }
        }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Status
        {
            get
            {
                if (Errors != null && Errors.Count > 0)
                    return "Error";

                if (string.IsNullOrEmpty(_Status))
                    return null;

                return _Status;
            }
            set
            {
                _Status = value;
            }
        }

        public string Message
        {
            set
            {
                _Message = value;
            }
            get
            {
                if (string.IsNullOrEmpty(_Message) && Errors.Count > 0)
                    return "See Errors.";

                return _Message;
            }
        }

        public void AddError(string key, string[] values)
        {
            _Errors.Add(key, values);
        }

        [IgnoreDataMember]
        public bool RequestIsValid
        {
            get
            {
                if (Errors == null || Errors.Count == 0)
                    return true;

                return false;
            }
        }
    }
}
