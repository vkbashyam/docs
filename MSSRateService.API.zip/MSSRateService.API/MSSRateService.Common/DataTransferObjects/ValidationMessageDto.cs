﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static MSSRateService.Common.Enums;

namespace MSSRateService.Common.DataTransferObjects
{
    public class ValidationMessageDto
    {
        [JsonIgnore]
        public LogLevel ValidationLevelValue  { get; set; }

        public string ValidationLevel { get; set; }

        public string ValidationMessage { get; set; }

        public ValidationMessageDto()
        {

        }

        public ValidationMessageDto(LogLevel level, string message)
        {
            ValidationLevelValue = level;
            ValidationLevel = Enum.GetName(typeof(LogLevel), ValidationLevelValue);
            ValidationMessage = message;
        }
    }
}
