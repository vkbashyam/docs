﻿using MSSRateService.Common.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MSSRateService.Common.DataTransferObjects
{
    public class CommandDto
    {
        public CommandDto()
        {
            Parameters = new List<TaskParameterVM>();
        }

        public string Command { get; set; }
        public List<TaskParameterVM> Parameters { get; set; }

        public override string ToString()
        {
            var parameters = Parameters.Select(m => m.TaskParameterValue).ToArray();

            return string.Format(Command, parameters);
        }
    }
}
