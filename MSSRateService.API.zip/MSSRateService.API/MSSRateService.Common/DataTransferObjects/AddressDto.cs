﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace MSSRateService.Common.DataTransferObjects
{
    public class AddressDto
    {
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string County { get; set; }        

        //[IgnoreDataMember]
        public string AddressKey { get; set; }

        /// <summary>
        /// (Melissa Address Key) A unique key assigned to the address record.
        /// </summary>
        //[IgnoreDataMember]
        public string MAK { get; set; }

        /// <summary>
        /// A unique key assigned to the base address of a complex with apartments or suites.
        /// </summary>
        //[IgnoreDataMember]
        public string BaseMAK { get; set; }

        [IgnoreDataMember]
        public int SuiteCount { get; set; }

        [IgnoreDataMember]
        public string[] Suites { get; set; }

        public string FreeFormAddress
        {
            get
            {
                return $"{(!string.IsNullOrEmpty(AddressLine2) ? $"{AddressLine2} - " : "")}{AddressLine1}, {City}, {State} {Zip}";
            }
        }
    }
}