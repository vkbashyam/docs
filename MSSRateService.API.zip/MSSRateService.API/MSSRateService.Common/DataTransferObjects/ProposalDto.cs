﻿using MSSRateService.Common.Interfaces;

namespace MSSRateService.Common.DataTransferObjects
{
    public class ProposalDto 
    {
        public Proposal Proposal { get; set; }        
    }

    public class Proposal //: ITransactionDto
    {
        public Proposal_Data Data { get; set; }
        public Proposal_Metadata Metadata { get; set; }
        public Proposal_Options Options { get; set; }
        public int TransactionId { get; set; }
    }

    public class Proposal_Data
    {
        public object GroupInfo { get; set; }
        public object Group { get; set; }
        public object Quote { get; set; }
        public object RenewingPlans { get; set; }
        public object Alternates { get; set; }
        public object MedicalBenefitSummaryInfo { get; set; }
    }

    public class Proposal_Metadata
    {
        public object Metadata { get; set; }
    }

    public class Proposal_Options
    {
        public object Options { get; set; }
    }
}
