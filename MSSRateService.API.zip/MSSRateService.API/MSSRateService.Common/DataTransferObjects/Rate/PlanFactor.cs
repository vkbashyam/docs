﻿using MSSRateService.Common.Interfaces.Rate;
using System.Xml.Serialization;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    [XmlRoot("PlanFactor")]
    public class PlanFactor : IXmlSerializedObject
    {
        public int RiskPoolSet { get; set; }
        public decimal? RiskPoolBaseRate { get; set; }
        public string DependentCountMethod { get; set; }
        public int AgeBandSet { get; set; }
        public int? Grandfathered { get; set; }
        public string RiskPoolSubType { get; set; }
        public int? SingleFamilyUnitMethod { get; set; }
        public string Unit { get; set; }
        public string PlanCode { get; set; }
        public string PackageCode { get; set; }
        public int? NetworkId { get; set; }
        public int? MacNetworkId { get; set; }
        public string PlanMarketingName { get; set; }
        public int PlanSet { get; set; }
        public string MaxRateArea { get; set; }
        public decimal Factor { get; set; }
        public int NetworkSet { get; set; }
        public int? CountyRateAreaSet { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public string AreaId { get; set; }
        public string RateArea { get; set; }
        public decimal? NetworkFactor { get; set; }
        public int MaxNetworkId { get; set; }
        public decimal? MaxNetworkFactor { get; set; }
        public decimal? AreaFactor { get; set; }
        public string AreaFactorRateArea { get; set; }

    }
}
