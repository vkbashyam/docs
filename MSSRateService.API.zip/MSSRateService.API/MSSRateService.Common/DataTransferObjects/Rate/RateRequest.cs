﻿using MSSRateService.Common.Interfaces.Rate;
using System;
using System.Collections.Generic;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    public class RateRequest : IXmlSerializedObject
    {
        public RateRequest()
        {
            ValidationMessages = new List<ValidationMessage>();
        }

        public int GroupNumber { get; set; }
        public DateTime RenewalDate { get; set; }
        public Enums.CoverageType CoverageType { get; set; }
        public string PackageCode { get; set; }
        public int NetworkId { get; set; }

        public GroupMetadata Group { get; set; }
        public PlanFactor PlanFactor { get; set; }
        public CensusRequest Census { get; set; }
        public List<AgeBand> AgeBands { get; set; }
        public List<ValidationMessage> ValidationMessages { get; set; }
    }
}
