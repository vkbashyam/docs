﻿using MSSRateService.Common.Interfaces.Rate;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    public class SubGroupPlan : IXmlSerializedObject
    {
        public string NetworkId { get; set; }
        public string PackageCode { get; set; }
        public string ContractAdjustmentFactor { get; set; }
        public string PackageType { get; set; }
        public string HospiceFlag { get; set; }
        public string PedicatricDentalFlag { get; set; }
    }
}
