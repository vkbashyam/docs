﻿using MSSRateService.Common.Interfaces.Rate;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    public class AgeBand : IXmlSerializedObject
    {
        public string AgeBandType { get; set; }
        public string Description { get; set; }
        public int MinimumAge { get; set; }
        public int MaximumAge { get; set; }
        public string Gender { get; set; }
        public decimal AgeFactor { get; set; }
        public decimal TobaccoFactor { get; set; }
        public decimal HealthAndWellnessFactor { get; set; }        
        public decimal NonTobaccoRate { get; set; }
        public decimal TobaccoRate { get; set; }
        public bool MaleBand 
        { 
            get
            {
                if (Gender == "M" || Gender == "B")
                    return true;

                return false;
            }
        }
        public bool FemaleBand 
        { 
            get 
            {
                if (Gender == "F" || Gender == "B")
                    return true;

                return false;
            } 
        }
    }
}
