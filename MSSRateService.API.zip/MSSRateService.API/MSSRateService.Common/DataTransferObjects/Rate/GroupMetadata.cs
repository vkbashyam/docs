﻿using MSSRateService.Common.Interfaces.Rate;
using System;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    [XmlRoot("Group")]
    public class GroupMetadata : IXmlSerializedObject
    {
        public GroupMetadata()
        {
            SubGroups = new List<SubGroup>();
        }

        //public int Id { get; set; }
        public string GroupNumber { get; set; }
        [XmlElement(DataType = "date")]
        public DateTime? LastRenewalDate { get; set; }
        public string State { get; set; }
        public string County { get; set; }
        public string DefaultCounty { get; set; }
        public string Zip { get; set; }
        public string MarketSegmentId { get; set; }
        public string MarketSegment { get; set; }
        public decimal ContractAdjustmentFactor { get; set; }
        public string Grandfathered { get; set; }
        [XmlElement(DataType = "date")]
        public DateTime? GrandfatheredEffectiveDate { get; set; }
        [XmlElement(DataType = "date")]
        public DateTime? GrandfatheredEndDate { get; set; }
        public string LicensingCorpId { get; set; }
        public string LicensingCorpName { get; set; }
        public string LicensingCorpAbrv { get; set; }
        public string LicensingState { get; set; }

        public List<SubGroup> SubGroups { get; set; }
    }
}
