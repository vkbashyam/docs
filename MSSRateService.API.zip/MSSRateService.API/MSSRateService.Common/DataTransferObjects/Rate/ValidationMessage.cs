﻿using MSSRateService.Common.Interfaces.Rate;
using System;
using System.Xml.Linq;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    public class ValidationMessage : IXmlSerializedObject
    {
        public ValidationMessage() {}

        public ValidationMessage(Enums.LogLevel level, string msg)
        {
            Level = level;
            Message = msg;
        }

        public Enums.LogLevel Level { get; set; }
        public string Message { get; set; }
        public object SourceReference { get; set; }

        public override string ToString()
        {
            var element = new XElement("ValidationMessage");
            element.Add(new XElement("Level", Enum.GetName(typeof(Enums.LogLevel), Level)));
            element.Add(new XElement("Message", Message));

            return element.ToString();
        }
    }
}
