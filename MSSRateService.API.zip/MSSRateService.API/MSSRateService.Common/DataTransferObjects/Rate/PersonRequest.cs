﻿using MSSRateService.Common.Interfaces.Rate;
using System;
using System.Xml.Serialization;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    [XmlRoot("Member")]
    public class PersonRequest1: IXmlSerializedObject
    {
        [XmlAttribute]
        public decimal Rate { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        [XmlElement(DataType = "date")]
        public DateTime BirthDate { get; set; }
        public string Gender { get; set; }
        public string Relationship { get; set; }
        public bool? IsTobaccoUser { get; set; }
        public bool? IsTobaccoCessation { get; set; }
        public bool? IsMedicalSubscriber { get; set; }
        public bool? IsDentalSubscriber { get; set; }
        public bool? IsBillable { get; set; }
        public string AgeBandType { get; set; }

        [XmlAttribute]
        public string MemberId { get; set; }
        public string State { get; set; }
        public string DsnId { get; set; }
        public string TobaccoCode { get; set; }
        [XmlElement(DataType = "date")]
        public DateTime? TobaccoUpdatedDate { get; set; }
        public string REL_TO_PH { get; set; }


        public string Name
        {
            get
            {
                string name = string.Empty;

                if (!string.IsNullOrEmpty(FirstName))
                    name += FirstName;
                else if (!string.IsNullOrEmpty(MiddleName))
                    name += $" {MiddleName}";
                else if (!string.IsNullOrEmpty(LastName))
                    name += $" {LastName}";

                return name;
            }
        }

        public int? Age
        {
            get
            {
                if (BirthDate.Date == new DateTime(1,1,1))
                    return null;

                return CalculateAge(DateTime.Today);
            }
        }

        public int? AgeByRenewalDate { get; set; }

        public int CalculateAge(DateTime date)
        {
            var age = date.Year - BirthDate.Year;

            if (BirthDate.Date > date.AddYears(-age))
                age--;

            return age;
        }
    }
}
