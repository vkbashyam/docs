﻿using MSSRateService.Common.Interfaces.Rate;
using System.Collections.Generic;
using System.Xml.Serialization;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    [XmlRoot("Family")]
    public class FamilyUnitRequest1 : IXmlSerializedObject
    {
        private string ContractNumberField;

        public FamilyUnitRequest1()
        {
            FamilyMembers = new List<PersonRequest>();
        }
        //public int SourceId { get; set; }
        //public string FirstName { get; set; }
        //public string MiddleName { get; set; }
        //public string LastName { get; set; }
        //public string Gender { get; set; }
        //public DateTime DateOfBirth { get; set; }
        //public int Age { get; set; }
        //public bool UsesTobacco { get; set; }
        //public bool InTobaccoCessation { get; set; }
        //public string Relationship { get; set; }
        //public string County { get; set; }


        [XmlAttribute]
        public decimal Rate { get; set; }
        [XmlAttribute]
        public decimal MedicalSubscriberRate { get; set; }
        [XmlAttribute]
        public string ContractNumber { get; set; }
        [XmlAttribute]
        public bool IsCobra { get; set; }
        [XmlIgnore]
        public bool IsCobraSpecified { get; set; }
        [XmlAttribute]
        public bool IsMedicare { get; set; }
        [XmlIgnore]
        public bool IsMedicareSpecified { get; set; }

        public List<PersonRequest> FamilyMembers { get; set; }
    }
}
