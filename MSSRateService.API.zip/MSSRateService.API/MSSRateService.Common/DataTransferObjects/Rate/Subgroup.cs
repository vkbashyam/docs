﻿using MSSRateService.Common.Interfaces.Rate;
using System.Collections.Generic;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    public class SubGroup : IXmlSerializedObject
    {
        public SubGroup()
        {
            Plans = new List<SubGroupPlan>();
        }

        public string Name { get; set; }
        public string TypeId { get; set; }
        public string SiteId { get; set; }
        public bool IsCobra { get; set; }
        public bool IsMedicare { get; set; }

        public List<SubGroupPlan> Plans { get; set; }        
    }
}
