﻿using MSSRateService.Common.Interfaces.Rate;
using System.Collections.Generic;
using System.Xml.Linq;
using System.Xml.Serialization;

namespace MSSRateService.Common.DataTransferObjects.Rate
{
    [XmlRoot("Census")]
    public class CensusRequest1 : IXmlSerializedObject
    {
        public CensusRequest1()
        {
            FamilyUnit = new List<FamilyUnitRequest>();
        }

        [XmlAttribute]
        public decimal Rate { get; set; }

        [XmlAttribute]
        public decimal MedicalSubscriberRate { get; set; }

        public List<FamilyUnitRequest> FamilyUnit { get; set; }

        [XmlIgnore]
        public List<ValidationMessage> ValidationMessages { get; set; }
    }

    public class CensusRequest : IXmlSerializedObject
    {
        public CensusRequest()
        {
            FamilyUnit = new List<FamilyUnitRequest>();
        }

        [System.Xml.Serialization.XmlElementAttribute("FamilyUnit")]
        public List<FamilyUnitRequest> FamilyUnit { get; set; }

        public List<ValidationMessage> Validations { get; set; }
        public decimal MedicalSubscriberRate { get; set; }
        public decimal Rate { get; set; }
    }

    public class FamilyUnitRequest : IXmlSerializedObject
    {
        public FamilyUnitRequest()
        {
            Person = new List<PersonRequest>();
        }

        public string ContractNumber { get; set; }

        [XmlAttribute]
        public bool IsCobra { get; set; }

        [XmlIgnore]
        public bool IsCobraSpecified;

        [XmlAttribute]
        public bool IsMedicare { get; set; }

        [XmlIgnore]
        public bool IsMedicareSpecified;

        [XmlElementAttribute("Person")]
        public List<PersonRequest> Person { get; set; }
        public decimal MedicalSubscriberRate { get; set; }
        public decimal Rate { get; set; }
    }

    public class PersonRequest : IXmlSerializedObject
    {
        [XmlAttribute]
        public decimal Rate { get; set; }
        public PersonRequest()
        {
            AdditionalDemographics = new AdditionalDemographics();
            AdditionalDemographics.Demographics = new List<XElement>();
        }

        public string LastName { get; set; }
        public string MiddleName { get; set; }
        public string FirstName { get; set; }
        public System.DateTime BirthDate { get; set; }
        public string Gender { get; set; }
        public string Relationship { get; set; }
        public bool? TobaccoUse { get; set; }
        public bool? TobaccoCessation { get; set; }
        public bool? IsMedicalSub { get; set; }
        public bool? IsDentalSub { get; set; }
        public string AgeBandType { get; set; }

        //[System.Xml.Serialization.XmlElementAttribute("additionalDemographics")]
        public AdditionalDemographics AdditionalDemographics { get; set; }
        public bool? IsBillable { get; set; }
        public int AgeByRenewalDate { get; set; }

        public string REL_TO_PH { get; set; }


        public string Name
        {
            get
            {
                string name = string.Empty;

                if (!string.IsNullOrEmpty(FirstName))
                    name += FirstName;
                else if (!string.IsNullOrEmpty(MiddleName))
                    name += $" {MiddleName}";
                else if (!string.IsNullOrEmpty(LastName))
                    name += $" {LastName}";

                return name;
            }
        }

        public int? Age
        {
            get
            {
                if (BirthDate.Date == new DateTime(1, 1, 1))
                    return null;

                return CalculateAge(DateTime.Today);
            }
        }

        public DateTime TobaccoUpdatedDate { get; set; }

        public int CalculateAge(DateTime date)
        {
            var age = date.Year - BirthDate.Year;

            if (BirthDate.Date > date.AddYears(-age))
                age--;

            return age;
        }
    }

    public class AdditionalDemographics
    {
        [XmlAnyElement]
        public List<XElement> Demographics { get; set; }
    }
}
