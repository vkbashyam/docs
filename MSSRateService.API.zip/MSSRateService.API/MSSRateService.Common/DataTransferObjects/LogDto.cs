﻿using System;

namespace MSSRateService.Common.DataTransferObjects
{
    public class LogDto
    {
        public int LogId { get; set; }
        public int ProcessId { get; set; }
        public string Process { get; set; }
        public DateTime TimeStamp { get; set; }
        public int StatusId { get; set; }
        public string Status { get; set; }
        public string JsonData { get; set; }
    }
}
