﻿using Aspose.Pdf.Drawing;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MSSRateService.Common.Attributes
{
    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false, Inherited = true)]
    public class AcceptableValuesAttribute : ValidationAttribute
    {
        private string[] _acceptableValues;

        public AcceptableValuesAttribute(string args)
        {
            var acceptable = new List<string>();
            foreach (var arg in args.Split(","))
                acceptable.Add(arg.Trim());

            _acceptableValues = acceptable.ToArray();
        }

        public override bool IsValid(object value)
        {
            foreach (var val in _acceptableValues)
            {
                if (val.Equals(value.ToString(), StringComparison.OrdinalIgnoreCase))
                    return true;
            }

            return false;
        }

        public override string FormatErrorMessage(string name)
        {
            return string.Format(ErrorMessageString, name);
        }

        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            foreach (var val in _acceptableValues)
            {
                if (val.Equals(value.ToString(), StringComparison.OrdinalIgnoreCase))
                    return ValidationResult.Success;
            }

            var members = new string[] { validationContext.MemberName };
            return new ValidationResult(FormatErrorMessage(value.ToString()), members);
        }
    }
}