﻿using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Linq;

namespace MSSRateService.Common.Helpers
{
    public static class JsonHelper
    {
        public static Dictionary<string, string> FlattenJsonStructure(string json, string prefix = "")
        {
            JObject jObj = JObject.Parse(json);

            if (!string.IsNullOrEmpty(prefix))
                prefix = $"{prefix}_";

            return jObj.Descendants()
                .Where(j => j.Children().Count() == 0)
                .Aggregate(
                    new Dictionary<string, string>(),
                    (props, jtoken) =>
                    {
                        props.Add($"{prefix}{jtoken.Path}", jtoken.ToString());
                        return props;
                    });
        }
    }

    public class ShortDate : IsoDateTimeConverter
    {
        public ShortDate()
        {
            base.DateTimeFormat = "yyyy-MM-dd";
        }
    }
}
