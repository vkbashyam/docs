﻿using Microsoft.AspNetCore.Authentication;
using MSSRateService.Common.DataTransferObjects;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.DirectoryServices.AccountManagement;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Threading.Tasks;

namespace MSSRateService.Common.Helpers
{
    public static class ActiveDirectoryHelper
    {
        public static UserDto GetUserContext(string username)
        {
            using (PrincipalContext context = new PrincipalContext(ContextType.Domain))
            {
                using (UserPrincipal user = UserPrincipal.FindByIdentity(context, username))
                {
                    var dto = new UserDto();

                    dto.FullName = $"{user.GivenName} {user.Surname}";
                    dto.Email = user.EmailAddress;
                    dto.SamAccountName = user.SamAccountName;

                    return dto;
                }
            }
        }

        //private static IEnumerable<string> GetAdGroups(ClaimsPrincipal claimsPrincipal)
        //{
        //    var windowsIdentity = (WindowsIdentity)claimsPrincipal.Identity;
        //    var groups = windowsIdentity.Groups.Select(m => m.Translate(typeof(NTAccount)).Value).ToList();
        //    return groups;
        //}

        //public static bool IsInRole(ClaimsPrincipal claimsPrincipal)
        //{
        //    return claimsPrincipal.IsInRole("");
        //}

        //public static bool IsInIndividualRole(ClaimsPrincipal claimsPrincipal)
        //{
        //    return claimsPrincipal.IsInRole("");
        //}
    }
}
