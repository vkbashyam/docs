﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace MSSRateService.Common.Helpers
{
    public static class StringHelper
    {
        public static string RemoveSharePointReserveSpecialCharacters(string text, string replacement = "")
        {
            //KX - 1/16/2023 - removed ' (apostrophe) - is allowed in on-prem sharepoint
            var reserved = @"[*:<>?/\|~#%&{}.@$;=]";
            return Regex.Replace(text, reserved, replacement);
        }

        /// <summary>
        /// Used for SharePoint calls where the url has an apostrophe, needs to have double to escape
        /// </summary>
        /// <param name="text"></param>
        /// <returns></returns>
        public static string EscapeApostrophe(string text)
        {
            return text.Replace("\'", "\'\'");
        }
    }
}
