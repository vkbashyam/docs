﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace MSSRateService.Common.Helpers
{
    public static class DecryptionHelper
    {
        public static string AesDecrypt(string encryptedString, byte[] key)
        {
            try
            {
                using (Aes aesAlg = Aes.Create())
                {
                    aesAlg.Key = key;
                    aesAlg.Mode = CipherMode.ECB;
                    aesAlg.Padding = PaddingMode.PKCS7;

                    ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, null);

                    byte[] encryptedByteArray = Convert.FromBase64String(encryptedString);
                    byte[] decryptedByteArray = decryptor.TransformFinalBlock(encryptedByteArray, 0, encryptedByteArray.Length);

                    return Encoding.UTF8.GetString(decryptedByteArray);
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }            
        }

        public static string TripleDesDecrypt(string encryptedString, byte[] key)
        {
            try
            {
                using (TripleDES des = TripleDES.Create())
                {
                    des.Key = key;
                    des.Mode = CipherMode.ECB;
                    des.Padding = PaddingMode.PKCS7;

                    ICryptoTransform decryptor = des.CreateDecryptor(des.Key, null);

                    byte[] encryptedByteArray = Convert.FromBase64String(encryptedString);
                    byte[] decryptedByteArray = decryptor.TransformFinalBlock(encryptedByteArray, 0, encryptedByteArray.Length);

                    return Encoding.UTF8.GetString(decryptedByteArray);
                }
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
    }
}
