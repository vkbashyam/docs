﻿using MSSRateService.Common.Extensions;
using Serilog;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Linq;
using System.Xml.XPath;
using System.Xml.Xsl;

namespace MSSRateService.Common.Helpers
{
    /// <summary>
    /// The XslCompiledTransform class in C# supports XSLT 1.0.
    /// While XSLT 2.0 offers more features and improvements over XSLT 1.0, the native .NET framework does not support XSLT 2.0.
    /// If you need to use XSLT 2.0, you would have to rely on a third-party library like Saxon
    /// </summary>
    public static class XsltHelper
    {
        private static readonly ILogger _seriLogger = Log.Logger;

        public static XDocument Transform(string xsl, string xml)
        {
            try
            {
                var specs = XDocument.Parse(xsl);
                var input = XDocument.Parse(xml);

                _seriLogger
                    .ForContext("Xsl", xsl)
                    .ForContext("Xml", xml)
                    .Debug("[Start XSLT Transform] Transformation start");

                var compiler = new XslCompiledTransform();
                compiler.Load(specs.CreateReader());

                using (var mem = new MemoryStream())
                {
                    using (var writer = XmlWriter.Create(mem))
                    {
                        compiler.Transform(input.CreateReader(), writer);
                    }

                    mem.Position = 0;
                    var reader = new StreamReader(mem);
                    var output = reader.ReadToEnd();
                    var results = XDocument.Parse(output);

                    _seriLogger
                        .ForContext("Results", results)
                        .Debug("[End XSLT Transform] Transform successful");

                    return results;
                }
            }
            catch (Exception ex)
            {
                _seriLogger.Exception(ex);
                throw;
            }            
        }
    }
}