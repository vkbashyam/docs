﻿using System;
using System.Xml.Linq;

namespace MSSRateService.Common.Helpers
{
    public static class ValidationHelper
    {
        public static XElement AddValidation(Enums.LogLevel level, string msg)
        {
            var xml = new XElement("ValidationMessage");

            xml.Add(new XElement("Level", Enum.GetName(typeof(Enums.LogLevel), level)));
            xml.Add(new XElement("Message", msg));

            return xml;
        }
    }
}
