﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblPlanSet", Schema = "Rate")]
    public partial class TblPlanSet
    {
        [Key]
        public int PlanSet { get; set; }
        [Key]
        [StringLength(50)]
        public string PlanCode { get; set; }
        [Key]
        [StringLength(1)]
        public string Unit { get; set; }
        [Key]
        public int NetworkSet { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal PlanFactor { get; set; }
        [StringLength(9)]
        public string MaxRateArea { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? InsertDate { get; set; }
    }
}
