﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblNetwork", Schema = "Rate")]
    public partial class TblNetwork
    {
        public TblNetwork()
        {
            TblNetworkSet = new HashSet<TblNetworkSet>();
            TblPlanDeliveryNetwork = new HashSet<TblPlanDeliveryNetwork>();
        }

        [Key]
        public int NetworkId { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NetworkEffDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? NetworkEndDate { get; set; }
        [StringLength(50)]
        public string NetworkInternalName { get; set; }
        [StringLength(50)]
        public string NetworkExternalName { get; set; }

        [InverseProperty("Network")]
        public virtual ICollection<TblNetworkSet> TblNetworkSet { get; set; }
        [InverseProperty("Network")]
        public virtual ICollection<TblPlanDeliveryNetwork> TblPlanDeliveryNetwork { get; set; }
    }
}
