﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblServiceAreaSet", Schema = "Rate")]
    public partial class TblServiceAreaSet
    {
        public TblServiceAreaSet()
        {
            TblServiceAreaSetZip = new HashSet<TblServiceAreaSetZip>();
        }

        [Key]
        [Column("ServiceAreaSetID")]
        public int ServiceAreaSetId { get; set; }
        public int ServiceAreaSet { get; set; }
        [Column("CorpID")]
        public int CorpId { get; set; }
        [Required]
        [StringLength(2)]
        public string State { get; set; }
        [Required]
        [StringLength(100)]
        public string CountyName { get; set; }
        [Column("NetworkID")]
        public int NetworkId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? InsertDate { get; set; }

        [InverseProperty("ServiceAreaSet")]
        public virtual ICollection<TblServiceAreaSetZip> TblServiceAreaSetZip { get; set; }
    }
}
