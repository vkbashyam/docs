﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblPlanDeliveryNetwork", Schema = "Rate")]
    public partial class TblPlanDeliveryNetwork
    {
        [Key]
        [StringLength(50)]
        public string PlanCode { get; set; }
        [Key]
        [Column("NetworkID")]
        public int NetworkId { get; set; }
        [Key]
        [Column("MACNetworkID")]
        public int MacnetworkId { get; set; }
        [Column("HIOSPlanID")]
        [StringLength(14)]
        public string HiosplanId { get; set; }
        [Key]
        [Column("MACNetworkEffDate", TypeName = "date")]
        public DateTime MacnetworkEffDate { get; set; }
        [Column("MACNetworkEndDate", TypeName = "date")]
        public DateTime? MacnetworkEndDate { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? InsertDate { get; set; }

        [ForeignKey(nameof(NetworkId))]
        [InverseProperty(nameof(TblNetwork.TblPlanDeliveryNetwork))]
        public virtual TblNetwork Network { get; set; }
    }
}
