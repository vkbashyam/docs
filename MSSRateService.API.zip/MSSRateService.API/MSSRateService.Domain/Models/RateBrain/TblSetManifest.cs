﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblSetManifest", Schema = "Rate")]
    public partial class TblSetManifest
    {
        [Key]
        public int SetManifestId { get; set; }
        public int? RiskPoolSet { get; set; }
        [StringLength(500)]
        public string FileName { get; set; }
        [StringLength(200)]
        public string TableName { get; set; }
        public int? RecordCount { get; set; }
        [StringLength(50)]
        public string FieldName { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal? FieldNameTotal { get; set; }
        [StringLength(5000)]
        public string Notes { get; set; }
        [Column("RateContainerID")]
        public int? RateContainerId { get; set; }
    }
}
