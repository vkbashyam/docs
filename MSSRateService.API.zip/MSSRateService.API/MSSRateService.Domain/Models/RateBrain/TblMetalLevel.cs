﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblMetalLevel", Schema = "Rate")]
    public partial class TblMetalLevel
    {
        [Key]
        [StringLength(30)]
        public string MetalLevel { get; set; }
        public byte? MetalLevelSort { get; set; }
    }
}
