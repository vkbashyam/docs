﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblPlan", Schema = "Rate")]
    public partial class TblPlan
    {
        [Key]
        [StringLength(50)]
        public string PlanCode { get; set; }
        [Column("HIOSPlanID")]
        [StringLength(14)]
        public string HiosplanId { get; set; }
        [StringLength(100)]
        public string PlanExternalName { get; set; }
        [StringLength(6)]
        public string GroupNumber { get; set; }
        [StringLength(30)]
        public string MetalLevel { get; set; }
        [Required]
        [StringLength(1)]
        public string CoverageType { get; set; }
        public byte SingleFlag { get; set; }
        public byte OnExchange { get; set; }
        [Key]
        [Column(TypeName = "date")]
        public DateTime PlanEffDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime PlanEndDate { get; set; }
        [StringLength(50)]
        public string ActuarialPlanCode { get; set; }
        [StringLength(100)]
        public string PlanInternalName { get; set; }
        [StringLength(60)]
        public string PlanCategory { get; set; }
        public byte? PlanCategorySort { get; set; }
        public byte? PlanSort { get; set; }
        [Column("OnIA")]
        public byte? OnIa { get; set; }
        [Column("OnEHeatlh")]
        public byte? OnEheatlh { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? InsertDate { get; set; }
        public byte? CreditableCoverage { get; set; }
    }
}
