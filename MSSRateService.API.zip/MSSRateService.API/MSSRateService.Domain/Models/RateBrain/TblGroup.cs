﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblGroup", Schema = "Rate")]
    public partial class TblGroup
    {
        [Key]
        [StringLength(6)]
        public string GroupNumber { get; set; }
        [Required]
        [StringLength(80)]
        public string GroupName { get; set; }
        [Required]
        [StringLength(100)]
        public string GroupNumberName { get; set; }
    }
}
