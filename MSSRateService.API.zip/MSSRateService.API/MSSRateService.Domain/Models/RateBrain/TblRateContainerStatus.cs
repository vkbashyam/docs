﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblRateContainerStatus", Schema = "Rate")]
    public partial class TblRateContainerStatus
    {
        public TblRateContainerStatus()
        {
            TblRateContainer = new HashSet<TblRateContainer>();
        }

        [Key]
        public int RateContainerStatusId { get; set; }
        [Required]
        [StringLength(40)]
        public string RateContainerStatus { get; set; }

        [InverseProperty("RateContainerStatus")]
        public virtual ICollection<TblRateContainer> TblRateContainer { get; set; }
    }
}
