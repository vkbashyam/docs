﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblAgeBandSet", Schema = "Rate")]
    public partial class TblAgeBandSet
    {
        [Key]
        public int AgeBandSet { get; set; }
        [Key]
        [StringLength(11)]
        public string AgeBandDesc { get; set; }
        [Key]
        public int MinAge { get; set; }
        [Key]
        public int MaxAge { get; set; }
        [Key]
        [StringLength(1)]
        public string Gender { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal AgeFactor { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal TobaccoFactor { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal HealthAndWellnessFactor { get; set; }
        [StringLength(1)]
        public string AgeBandType { get; set; }
    }
}
