﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblRateContainer", Schema = "Rate")]
    public partial class TblRateContainer
    {
        [Key]
        [Column("RateContainerID")]
        public int RateContainerId { get; set; }
        [Column("RateContainerStatusID")]
        public int RateContainerStatusId { get; set; }
        [Required]
        [StringLength(80)]
        public string RateContainerName { get; set; }
        [Required]
        [StringLength(80)]
        public string RateContainerNameExternal { get; set; }
        public int RiskPoolSet { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EffDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CreateDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? RejectionDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? ActivationDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? DiscontinueDate { get; set; }
        [StringLength(1000)]
        public string Note { get; set; }

        [ForeignKey(nameof(RateContainerStatusId))]
        [InverseProperty(nameof(TblRateContainerStatus.TblRateContainer))]
        public virtual TblRateContainerStatus RateContainerStatus { get; set; }
    }
}
