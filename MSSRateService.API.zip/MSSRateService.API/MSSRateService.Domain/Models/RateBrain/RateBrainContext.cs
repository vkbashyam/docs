﻿using Microsoft.EntityFrameworkCore;

namespace MSSRateService.Domain.Models.RateBrain
{
    public partial class RateBrainContext : DbContext
    {
        public RateBrainContext()
        {
        }

        public RateBrainContext(DbContextOptions<RateBrainContext> options)
            : base(options)
        {
        }

        public virtual DbSet<TblAgeBandSet> TblAgeBandSet { get; set; }
        public virtual DbSet<TblAreaSet> TblAreaSet { get; set; }
        public virtual DbSet<TblCalculatedRates> TblCalculatedRates { get; set; }
        public virtual DbSet<TblCorporation> TblCorporation { get; set; }
        public virtual DbSet<TblCountyRateAreaSet> TblCountyRateAreaSet { get; set; }
        public virtual DbSet<TblGroup> TblGroup { get; set; }
        public virtual DbSet<TblMetalLevel> TblMetalLevel { get; set; }
        public virtual DbSet<TblNetwork> TblNetwork { get; set; }
        public virtual DbSet<TblNetworkSet> TblNetworkSet { get; set; }
        public virtual DbSet<TblPlan> TblPlan { get; set; }
        public virtual DbSet<TblPlanDeliveryNetwork> TblPlanDeliveryNetwork { get; set; }
        public virtual DbSet<TblPlanPkg> TblPlanPkg { get; set; }
        public virtual DbSet<TblPlanSet> TblPlanSet { get; set; }
        public virtual DbSet<TblRateContainer> TblRateContainer { get; set; }
        public virtual DbSet<TblRateContainerStatus> TblRateContainerStatus { get; set; }
        public virtual DbSet<TblRiskPoolSet> TblRiskPoolSet { get; set; }
        public virtual DbSet<TblServiceAreaSet> TblServiceAreaSet { get; set; }
        public virtual DbSet<TblServiceAreaSetBak> TblServiceAreaSetBak { get; set; }
        public virtual DbSet<TblServiceAreaSetZip> TblServiceAreaSetZip { get; set; }
        public virtual DbSet<TblSetManifest> TblSetManifest { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
//            if (!optionsBuilder.IsConfigured)
//            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("server=HPMSSSQLDEV;database=RateBrain;user id =WebSQLAccount;password=Fas270!HP;");
//            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<TblAgeBandSet>(entity =>
            {
                entity.HasKey(e => new { e.AgeBandSet, e.AgeBandDesc, e.MinAge, e.MaxAge, e.Gender });

                entity.Property(e => e.AgeBandDesc).IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.AgeBandType).IsUnicode(false);
            });

            modelBuilder.Entity<TblAreaSet>(entity =>
            {
                entity.HasKey(e => new { e.AreaSet, e.RateArea });

                entity.Property(e => e.RateArea).IsUnicode(false);

                entity.Property(e => e.RateAreaSort).IsUnicode(false);
            });

            modelBuilder.Entity<TblCalculatedRates>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.AgeBandDesc).IsUnicode(false);

                entity.Property(e => e.AgeBandType).IsUnicode(false);

                entity.Property(e => e.CalculatedRatesDesc).IsUnicode(false);

                entity.Property(e => e.Gender)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.GroupNumber).IsUnicode(false);

                entity.Property(e => e.GroupType).IsUnicode(false);

                entity.Property(e => e.HiosplanId).IsUnicode(false);

                entity.Property(e => e.MarketSegment).IsUnicode(false);

                entity.Property(e => e.NetworkRateArea).IsUnicode(false);

                entity.Property(e => e.PkgCode).IsUnicode(false);

                entity.Property(e => e.PlanName).IsUnicode(false);

                entity.Property(e => e.RateArea).IsUnicode(false);

                entity.Property(e => e.RateAreaType).IsUnicode(false);

                entity.Property(e => e.RateContainerName).IsUnicode(false);

                entity.Property(e => e.RiskPoolName).IsUnicode(false);

                entity.Property(e => e.RiskPoolSubType).IsUnicode(false);

                entity.Property(e => e.State)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.Unit)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<TblCorporation>(entity =>
            {
                entity.Property(e => e.CorpId).ValueGeneratedNever();

                entity.Property(e => e.CorpAbrv).IsUnicode(false);

                entity.Property(e => e.CorpName).IsUnicode(false);
            });

            modelBuilder.Entity<TblCountyRateAreaSet>(entity =>
            {
                entity.HasKey(e => new { e.CountyRateAreaSet, e.AreaId, e.State, e.CountyName });

                entity.Property(e => e.AreaId)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.State)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.CountyName).IsUnicode(false);

                entity.Property(e => e.RateArea).IsUnicode(false);
            });

            modelBuilder.Entity<TblGroup>(entity =>
            {
                entity.Property(e => e.GroupNumber).IsUnicode(false);

                entity.Property(e => e.GroupName).IsUnicode(false);

                entity.Property(e => e.GroupNumberName).IsUnicode(false);
            });

            modelBuilder.Entity<TblMetalLevel>(entity =>
            {
                entity.Property(e => e.MetalLevel).IsUnicode(false);
            });

            modelBuilder.Entity<TblNetwork>(entity =>
            {
                entity.Property(e => e.NetworkId).ValueGeneratedNever();

                entity.Property(e => e.NetworkExternalName).IsUnicode(false);

                entity.Property(e => e.NetworkInternalName).IsUnicode(false);
            });

            modelBuilder.Entity<TblNetworkSet>(entity =>
            {
                entity.HasKey(e => new { e.NetworkSet, e.RateArea, e.NetworkId });

                entity.Property(e => e.RateArea).IsUnicode(false);

                entity.Property(e => e.InsertDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Network)
                    .WithMany(p => p.TblNetworkSet)
                    .HasForeignKey(d => d.NetworkId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblNetworkSet_tblNetwork");
            });

            modelBuilder.Entity<TblPlan>(entity =>
            {
                entity.HasKey(e => new { e.PlanCode, e.PlanEffDate });

                entity.Property(e => e.ActuarialPlanCode).IsUnicode(false);

                entity.Property(e => e.CoverageType)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasDefaultValueSql("('M')");

                entity.Property(e => e.GroupNumber).IsUnicode(false);

                entity.Property(e => e.HiosplanId).IsUnicode(false);

                entity.Property(e => e.InsertDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MetalLevel).IsUnicode(false);

                entity.Property(e => e.OnEheatlh)
                    .HasDefaultValueSql("((0))")
                    .HasComment("Indicates whether plan is available for shopping on eHealth");

                entity.Property(e => e.OnIa)
                    .HasDefaultValueSql("((0))")
                    .HasComment("Indicates whether plan is available for shopping on InsureAdvantage");

                entity.Property(e => e.PlanCategory).IsUnicode(false);

                entity.Property(e => e.PlanCategorySort).HasComment("Denormalized sort order for PlanCategory. Used in combination with PlanSort for reporting purposes (Broker Web Rate Sheet).");

                entity.Property(e => e.PlanExternalName).IsUnicode(false);

                entity.Property(e => e.PlanInternalName).IsUnicode(false);

                entity.Property(e => e.PlanSort).HasComment("Sort order for plans within each PlanCategory. Used in combination with PlanSort for reporting purposes (Broker Web Rate Sheet).");
            });

            modelBuilder.Entity<TblPlanDeliveryNetwork>(entity =>
            {
                entity.HasKey(e => new { e.PlanCode, e.NetworkId, e.MacnetworkId, e.MacnetworkEffDate })
                    .IsClustered(false);

                entity.Property(e => e.HiosplanId).IsUnicode(false);

                entity.Property(e => e.InsertDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.Network)
                    .WithMany(p => p.TblPlanDeliveryNetwork)
                    .HasForeignKey(d => d.NetworkId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblPlanDeliveryNetwork_tblNetwork");
            });

            modelBuilder.Entity<TblPlanPkg>(entity =>
            {
                entity.HasKey(e => new { e.PlanCode, e.PkgCode, e.PkgEffDate });

                entity.Property(e => e.PlanCode).IsUnicode(false);

                entity.Property(e => e.PkgCode).IsUnicode(false);

                entity.Property(e => e.InsertDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.PlanMarketingName).IsUnicode(false);

                entity.Property(e => e.VariationTypeId).IsUnicode(false);
            });

            modelBuilder.Entity<TblPlanSet>(entity =>
            {
                entity.HasKey(e => new { e.PlanSet, e.PlanCode, e.Unit, e.NetworkSet });

                entity.Property(e => e.Unit)
                    .IsUnicode(false)
                    .IsFixedLength();

                entity.Property(e => e.InsertDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.MaxRateArea).IsUnicode(false);
            });

            modelBuilder.Entity<TblRateContainer>(entity =>
            {
                entity.Property(e => e.RateContainerId).ValueGeneratedNever();

                entity.Property(e => e.Note).IsUnicode(false);

                entity.Property(e => e.RateContainerName).IsUnicode(false);

                entity.Property(e => e.RateContainerNameExternal).IsUnicode(false);

                entity.HasOne(d => d.RateContainerStatus)
                    .WithMany(p => p.TblRateContainer)
                    .HasForeignKey(d => d.RateContainerStatusId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblRateContainer_tblRateContainerStatus");
            });

            modelBuilder.Entity<TblRateContainerStatus>(entity =>
            {
                entity.Property(e => e.RateContainerStatusId).ValueGeneratedNever();

                entity.Property(e => e.RateContainerStatus).IsUnicode(false);
            });

            modelBuilder.Entity<TblRiskPoolSet>(entity =>
            {
                entity.HasKey(e => new { e.RiskPoolSet, e.CorpId, e.State, e.MarketSegment, e.GroupType, e.RiskPoolSubType, e.Grandfathered });

                entity.Property(e => e.State)
                    .IsUnicode(false)
                    .IsFixedLength()
                    .HasComment("state of issuance for the risk pool");

                entity.Property(e => e.MarketSegment).IsUnicode(false);

                entity.Property(e => e.GroupType).IsUnicode(false);

                entity.Property(e => e.RiskPoolSubType).IsUnicode(false);

                entity.Property(e => e.RateAreaType).IsUnicode(false);

                entity.Property(e => e.RiskPoolName).IsUnicode(false);

                entity.HasOne(d => d.Corp)
                    .WithMany(p => p.TblRiskPoolSet)
                    .HasForeignKey(d => d.CorpId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_tblRiskPoolSet_tblCorporation");
            });

            modelBuilder.Entity<TblServiceAreaSet>(entity =>
            {
                entity.HasIndex(e => new { e.ServiceAreaSet, e.CorpId, e.State, e.CountyName, e.NetworkId })
                    .HasDatabaseName("IX_tblServiceAreaSet")
                    .IsUnique();

                entity.Property(e => e.CountyName).IsUnicode(false);

                entity.Property(e => e.InsertDate).HasDefaultValueSql("(getdate())");

                entity.Property(e => e.State)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<TblServiceAreaSetBak>(entity =>
            {
                entity.HasNoKey();

                entity.Property(e => e.CountyName).IsUnicode(false);

                entity.Property(e => e.State)
                    .IsUnicode(false)
                    .IsFixedLength();
            });

            modelBuilder.Entity<TblServiceAreaSetZip>(entity =>
            {
                entity.HasKey(e => new { e.ServiceAreaSetId, e.Zip });

                entity.Property(e => e.Zip).IsUnicode(false);

                entity.Property(e => e.InsertDate).HasDefaultValueSql("(getdate())");

                entity.HasOne(d => d.ServiceAreaSet)
                    .WithMany(p => p.TblServiceAreaSetZip)
                    .HasForeignKey(d => d.ServiceAreaSetId)
                    .HasConstraintName("FK_Rate_tblServiceAreaSet");
            });

            modelBuilder.Entity<TblSetManifest>(entity =>
            {
                entity.Property(e => e.FieldName).IsUnicode(false);

                entity.Property(e => e.FileName).IsUnicode(false);

                entity.Property(e => e.Notes).IsUnicode(false);

                entity.Property(e => e.TableName).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
