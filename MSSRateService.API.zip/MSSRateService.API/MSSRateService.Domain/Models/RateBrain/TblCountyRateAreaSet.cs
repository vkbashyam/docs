﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblCountyRateAreaSet", Schema = "Rate")]
    public partial class TblCountyRateAreaSet
    {
        [Key]
        public int CountyRateAreaSet { get; set; }
        [Key]
        [StringLength(2)]
        public string State { get; set; }
        [Key]
        [StringLength(100)]
        public string CountyName { get; set; }
        [Key]
        [Column("AreaID")]
        [StringLength(4)]
        public string AreaId { get; set; }
        [Required]
        [StringLength(9)]
        public string RateArea { get; set; }
    }
}
