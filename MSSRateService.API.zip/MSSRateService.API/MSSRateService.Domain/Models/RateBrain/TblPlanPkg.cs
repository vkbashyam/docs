﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblPlanPkg", Schema = "Rate")]
    public partial class TblPlanPkg
    {
        [Key]
        [StringLength(50)]
        public string PlanCode { get; set; }
        [Key]
        [StringLength(20)]
        public string PkgCode { get; set; }
        [Key]
        [Column(TypeName = "date")]
        public DateTime PkgEffDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime PkgEndDate { get; set; }
        [Column("NetworkID")]
        public int? NetworkId { get; set; }
        [Column("MACNetworkID")]
        public int? MacnetworkId { get; set; }
        [Column("VariationTypeID")]
        [StringLength(5)]
        public string VariationTypeId { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? InsertDate { get; set; }
        [StringLength(100)]
        public string PlanMarketingName { get; set; }
    }
}
