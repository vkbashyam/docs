﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblNetworkSet", Schema = "Rate")]
    public partial class TblNetworkSet
    {
        [Key]
        public int NetworkSet { get; set; }
        [Key]
        [StringLength(13)]
        public string RateArea { get; set; }
        [Key]
        public int NetworkId { get; set; }
        [Column("NetworkName-NotUsed")]
        [StringLength(50)]
        public string NetworkNameNotUsed { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal? NetworkFactor { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? InsertDate { get; set; }

        [ForeignKey(nameof(NetworkId))]
        [InverseProperty(nameof(TblNetwork.TblNetworkSet))]
        public virtual TblNetwork Network { get; set; }
    }
}
