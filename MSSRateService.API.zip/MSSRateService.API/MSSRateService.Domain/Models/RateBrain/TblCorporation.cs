﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblCorporation", Schema = "Rate")]
    public partial class TblCorporation
    {
        public TblCorporation()
        {
            TblRiskPoolSet = new HashSet<TblRiskPoolSet>();
        }

        [Key]
        public int CorpId { get; set; }
        [Required]
        [StringLength(50)]
        public string CorpName { get; set; }
        [StringLength(50)]
        public string CorpAbrv { get; set; }

        [InverseProperty("Corp")]
        public virtual ICollection<TblRiskPoolSet> TblRiskPoolSet { get; set; }
    }
}
