﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblRiskPoolSet", Schema = "Rate")]
    public partial class TblRiskPoolSet
    {
        [Key]
        public int RiskPoolSet { get; set; }
        public int RiskPoolId { get; set; }
        [Required]
        [StringLength(100)]
        public string RiskPoolName { get; set; }
        [Key]
        public int CorpId { get; set; }
        [Key]
        [StringLength(2)]
        public string State { get; set; }
        [Key]
        [StringLength(40)]
        public string MarketSegment { get; set; }
        [Key]
        [StringLength(40)]
        public string GroupType { get; set; }
        [Key]
        [StringLength(40)]
        public string RiskPoolSubType { get; set; }
        public int? DepCountMethod { get; set; }
        public int? SingFamUnitMethod { get; set; }
        [Key]
        public byte Grandfathered { get; set; }
        public int CountyRateAreaSet { get; set; }
        public int AreaSet { get; set; }
        public int AgeBandSet { get; set; }
        public int PlanSet { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal? RiskPoolBaseRate { get; set; }
        [StringLength(6)]
        public string RateAreaType { get; set; }
        public int? ServiceAreaSet { get; set; }

        [ForeignKey(nameof(CorpId))]
        [InverseProperty(nameof(TblCorporation.TblRiskPoolSet))]
        public virtual TblCorporation Corp { get; set; }
    }
}
