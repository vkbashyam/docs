﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblServiceAreaSetZip", Schema = "Rate")]
    public partial class TblServiceAreaSetZip
    {
        [Key]
        [Column("ServiceAreaSetID")]
        public int ServiceAreaSetId { get; set; }
        [Key]
        [StringLength(10)]
        public string Zip { get; set; }
        [Column(TypeName = "datetime")]
        public DateTime? InsertDate { get; set; }

        [ForeignKey(nameof(ServiceAreaSetId))]
        [InverseProperty(nameof(TblServiceAreaSet.TblServiceAreaSetZip))]
        public virtual TblServiceAreaSet ServiceAreaSet { get; set; }
    }
}
