﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

#nullable disable

namespace MSSRateService.Domain.Models.RateBrain
{
    //[Keyless]
    [Table("tblCalculatedRates", Schema = "Rate")]
    public partial class TblCalculatedRate
    {
        [StringLength(500)]
        public string CalculatedRatesDesc { get; set; }
        public byte TobaccoUse { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal? CalculatedRate { get; set; }
        public int RiskPoolSet { get; set; }
        [Required]
        [StringLength(100)]
        public string RateContainerName { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EffDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? EndDate { get; set; }
        public int RiskPoolId { get; set; }
        [Required]
        [StringLength(100)]
        public string RiskPoolName { get; set; }
        public int CorpId { get; set; }
        [Required]
        [StringLength(2)]
        public string State { get; set; }
        [Required]
        [StringLength(40)]
        public string MarketSegment { get; set; }
        [Required]
        [StringLength(40)]
        public string GroupType { get; set; }
        [Required]
        [StringLength(40)]
        public string RiskPoolSubType { get; set; }
        public int? DepCountMethod { get; set; }
        public int? SingFamUnitMethod { get; set; }
        public byte Grandfathered { get; set; }
        [Column("riskpoolCountyRateAreaSet")]
        public int RiskpoolCountyRateAreaSet { get; set; }
        [Column("riskpoolAreaSet")]
        public int RiskpoolAreaSet { get; set; }
        [Column("riskpoolAgeBandSet")]
        public int RiskpoolAgeBandSet { get; set; }
        [Column("riskpoolPlanSet")]
        public int RiskpoolPlanSet { get; set; }
        [Column("riskpoolBaseRate", TypeName = "decimal(18, 4)")]
        public decimal? RiskpoolBaseRate { get; set; }
        [StringLength(6)]
        public string RateAreaType { get; set; }
        public int AgeBandSet { get; set; }
        [Required]
        [StringLength(11)]
        public string AgeBandDesc { get; set; }
        public int MinAge { get; set; }
        public int MaxAge { get; set; }
        [Required]
        [StringLength(1)]
        public string Gender { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal AgeFactor { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal TobaccoFactor { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal HealthAndWellnessFactor { get; set; }
        public int AreaSet { get; set; }
        [Required]
        [StringLength(9)]
        public string RateArea { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal? AreaFactor { get; set; }
        public int PlanSet { get; set; }
        [Required]
        [StringLength(50)]
        public string PlanCode { get; set; }
        [Required]
        [StringLength(1)]
        public string Unit { get; set; }
        [Column("planNetworkSet")]
        public int PlanNetworkSet { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal PlanFactor { get; set; }
        [StringLength(100)]
        public string PlanName { get; set; }
        public int NetworkSet { get; set; }
        [Required]
        [Column("networkRateArea")]
        [StringLength(13)]
        public string NetworkRateArea { get; set; }
        public int NetworkId { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal? NetworkFactor { get; set; }
        [StringLength(50)]
        public string NetworkName { get; set; }
        [StringLength(20)]
        public string PkgCode { get; set; }
        [Column("HIOSPlanID")]
        [StringLength(14)]
        public string HiosplanId { get; set; }
        [Column("MACNetworkId")]
        public int? MacnetworkId { get; set; }
        [Column("RateContainerID")]
        public int? RateContainerId { get; set; }
        [StringLength(1)]
        public string AgeBandType { get; set; }
        [StringLength(6)]
        public string GroupNumber { get; set; }
        public byte? OnExchange { get; set; }
        [Column("OnIA")]
        public byte? OnIa { get; set; }
    }
}
