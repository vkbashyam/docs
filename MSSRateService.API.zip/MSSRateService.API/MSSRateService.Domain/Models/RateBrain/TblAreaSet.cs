﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.RateBrain
{
    [Table("tblAreaSet", Schema = "Rate")]
    public partial class TblAreaSet
    {
        [Key]
        public int AreaSet { get; set; }
        [Key]
        [StringLength(9)]
        public string RateArea { get; set; }
        [Column(TypeName = "decimal(18, 4)")]
        public decimal? AreaFactor { get; set; }
        [StringLength(10)]
        public string RateAreaSort { get; set; }
    }
}
