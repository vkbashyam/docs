﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace MSSRateService.Domain.Models.AgentOfRecord
{
    public partial class AgentofRecordContext : DbContext
    {
        public AgentofRecordContext()
        {
        }

        public AgentofRecordContext(DbContextOptions<AgentofRecordContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Broker> Broker { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
//#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
//                optionsBuilder.UseSqlServer("server=HPMSSSQLDEV;database=AgentofRecord;user id=WebSQLAccount;password=Fas270!HP;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Broker>(entity =>
            {
                entity.Property(e => e.BrokerId).ValueGeneratedNever();

                entity.Property(e => e.Address1).IsUnicode(false);

                entity.Property(e => e.Address2).IsUnicode(false);

                entity.Property(e => e.BrokerEmail).IsUnicode(false);

                entity.Property(e => e.BrokerFirstName).IsUnicode(false);

                entity.Property(e => e.BrokerLastName).IsUnicode(false);

                entity.Property(e => e.BrokerName).IsUnicode(false);

                entity.Property(e => e.City).IsUnicode(false);

                entity.Property(e => e.EopolicyHolder).IsUnicode(false);

                entity.Property(e => e.Fax).IsUnicode(false);

                entity.Property(e => e.HealthPlan).IsUnicode(false);

                entity.Property(e => e.InsAgentType).IsUnicode(false);

                entity.Property(e => e.Npn).IsUnicode(false);

                entity.Property(e => e.Phone).IsUnicode(false);

                entity.Property(e => e.State).IsUnicode(false);

                entity.Property(e => e.Status).IsUnicode(false);

                entity.Property(e => e.Zip).IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
