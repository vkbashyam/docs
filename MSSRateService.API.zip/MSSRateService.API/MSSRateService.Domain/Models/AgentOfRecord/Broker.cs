﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace MSSRateService.Domain.Models.AgentOfRecord
{
    public partial class Broker
    {
        [Key]
        [Column("BrokerID")]
        public int BrokerId { get; set; }
        public int? BrokerNbr { get; set; }
        [StringLength(50)]
        public string BrokerLastName { get; set; }
        [StringLength(50)]
        public string BrokerFirstName { get; set; }
        [StringLength(50)]
        public string BrokerName { get; set; }
        [StringLength(50)]
        public string Address1 { get; set; }
        [StringLength(50)]
        public string Address2 { get; set; }
        [StringLength(30)]
        public string City { get; set; }
        [StringLength(10)]
        public string State { get; set; }
        [StringLength(10)]
        public string Zip { get; set; }
        public int? PhoneAreaCode { get; set; }
        [StringLength(10)]
        public string Phone { get; set; }
        public int? FaxAreaCode { get; set; }
        [StringLength(10)]
        public string Fax { get; set; }
        [StringLength(2)]
        public string Status { get; set; }
        [Column(TypeName = "date")]
        public DateTime? StatusDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? CurrentContractDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? AgreementSentDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? AgreementSignedDate { get; set; }
        [Column("EOInsuranceStartDate", TypeName = "date")]
        public DateTime? EoinsuranceStartDate { get; set; }
        [Column("EOInsuranceExpDate", TypeName = "date")]
        public DateTime? EoinsuranceExpDate { get; set; }
        [Column("EOPolicyHolder")]
        [StringLength(40)]
        public string EopolicyHolder { get; set; }
        [Column(TypeName = "date")]
        public DateTime? LicenseExpDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? InactiveDate { get; set; }
        [StringLength(10)]
        public string HealthPlan { get; set; }
        [Column("NPN")]
        [StringLength(20)]
        public string Npn { get; set; }
        [StringLength(15)]
        public string InsAgentType { get; set; }
        [StringLength(200)]
        public string BrokerEmail { get; set; }
        [Column("ADWCreateDate", TypeName = "date")]
        public DateTime? AdwcreateDate { get; set; }
        [Column("ADWModifiedDate", TypeName = "date")]
        public DateTime? AdwmodifiedDate { get; set; }
        [Column(TypeName = "date")]
        public DateTime? InsertDate { get; set; }
    }
}
